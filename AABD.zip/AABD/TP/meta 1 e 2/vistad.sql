CREATE OR REPLACE VIEW VIEW_H AS 
SELECT *
FROM (
    SELECT v.idveiculo AS ID_VEICULO, 
           COUNT(DISTINCT c.idMaquina) AS N_MAQUINAS_REABASTE,
           COUNT(vi.idViagem) AS N_VIAGENS
    FROM Viagem vi
    JOIN Veiculo v ON vi.idveiculo = v.idveiculo
    JOIN Abastecimento abo ON vi.idViagem = abo.idViagem
    JOIN Abastece ab ON abo.idAbastecimento = ab.idAbastecimento
    JOIN Compartimento c ON ab.idCompartimento = c.idCompartimento
    JOIN Produto p ON c.idProduto = p.idProduto
    WHERE p.tipo = 'AGUA'
      AND vi.km_percorridos > 50    
      AND EXTRACT(YEAR FROM vi.data_hora_inicio) = EXTRACT(YEAR FROM SYSDATE)
      AND EXTRACT(MONTH FROM vi.data_hora_inicio) = EXTRACT(MONTH FROM SYSDATE) - 1
    GROUP BY v.idveiculo
    HAVING COUNT(DISTINCT c.idMaquina) >= 3
    ORDER BY COUNT(vi.idViagem) DESC
) 
WHERE ROWNUM <= 5;


----Mostra os funcion�rio que fizeram mais abastecimentos

CREATE OR REPLACE VIEW VIEW_J_2023134919 AS
SELECT
    ab.idFuncionario,
    f.nome,
    COUNT(ab.idAbastecimento) AS total_abastecimentos,
    SUM(ab.quantAbastecida) AS total_abastecido
FROM
    Abastecimento ab
JOIN Funcionario f ON ab.idFuncionario = f.idFuncionario
GROUP BY
    ab.idFuncionario, f.nome
ORDER BY TOTAL_ABASTECIDO DESC;

CREATE OR REPLACE VIEW VIEW_K_2023134919 AS