//a)
CREATE OR REPLACE FUNCTION quantidade_vendida(id_maquina NUMBER, id_produto NUMBER, dataInicio DATE, dataFim DATE) RETURN NUMBER 
IS
    quant     NUMBER;
    m_existe  NUMBER;
    p_existe  NUMBER;
BEGIN
    -- Verifica se a m�quina existe
    SELECT COUNT(*) INTO m_existe
    FROM Maquina
    WHERE idMaquina = id_maquina;

    IF m_existe = 0 THEN
        RAISE_APPLICATION_ERROR(-20801, 'C�digo de m�quina inexistente');
    END IF;

    -- Verifica se o produto existe
    SELECT COUNT(*) INTO p_existe
    FROM Produto
    WHERE idProduto = id_produto;

    IF p_existe = 0 THEN
        RAISE_APPLICATION_ERROR(-20802, 'C�digo de produto inexistente');
    END IF;

    -- Verifica se o intervalo � v�lido
    IF dataInicio > dataFim THEN
        RAISE_APPLICATION_ERROR(-20809, 'Intervalo temporal inv�lido');
    END IF;

    -- Conta a quantidade vendida
    SELECT COUNT(*) INTO quant
    FROM Venda v
    JOIN Compartimento c ON v.idCompartimento = c.idCompartimento
    WHERE v.idMaquina = id_maquina
      AND c.idProduto = id_produto
      AND v.data BETWEEN dataInicio AND dataFim;

    RETURN quant;

END;
/

SELECT quantidade_vendida(401,301,TO_DATE('25-03-2001', 'DD-MM-YYYY'),SYSDATE) FROM dual;

//b)
CREATE OR REPLACE FUNCTION quantidade_em_falta(id_maquina IN NUMBER, id_produto IN NUMBER) RETURN NUMBER 
IS
      quant_existente NUMBER;
      capacidade NUMBER;
      quant_em_falta NUMBER;
      m_existe NUMBER;
      p_existe NUMBER;
BEGIN
  -- Verifica se a m�quina existe
    SELECT COUNT(*) INTO m_existe
    FROM Maquina
    WHERE idMaquina = id_maquina;

    IF m_existe = 0 THEN
        RAISE_APPLICATION_ERROR(-20801, 'C�digo de m�quina inexistente');
    END IF;

    -- Verifica se o produto existe
    SELECT COUNT(*) INTO p_existe
    FROM Produto
    WHERE idProduto = id_produto;

    IF p_existe = 0 THEN
        RAISE_APPLICATION_ERROR(-20802, 'C�digo de produto inexistente');
    END IF;

  -- Somar a quantidade existente e capacidade total nos compartimentos da m�quina para esse produto
  SELECT SUM(c.capacidadeatual), SUM(c.capacidademaxi)
  INTO quant_existente, capacidade
  FROM Compartimento c
  WHERE c.idMaquina = id_maquina
    AND c.idProduto = id_produto;

  -- Calcular o que falta
  quant_em_falta := capacidade - quant_existente;

  RETURN quant_em_falta;

END;
/

SELECT quantidade_em_falta(401, 301) FROM dual;


//c)
CREATE OR REPLACE FUNCTION quantidade_media_diaria(id_maquina IN NUMBER, id_produto IN NUMBER) RETURN NUMBER 
IS
    m_existe NUMBER;
    p_existe NUMBER;
    total_vendido NUMBER := 0;
    data_inicio DATE;
    dias NUMBER := 1;
    media NUMBER := 0;
BEGIN
     -- Verifica se a m�quina existe
        SELECT COUNT(*) INTO m_existe
        FROM Maquina
        WHERE idMaquina = id_maquina;
    
        IF m_existe = 0 THEN
            RAISE_APPLICATION_ERROR(-20801, 'C�digo de m�quina inexistente');
        END IF;
    
        -- Verifica se o produto existe
        SELECT COUNT(*) INTO p_existe
        FROM Produto
        WHERE idProduto = id_produto;
    
        IF p_existe = 0 THEN
            RAISE_APPLICATION_ERROR(-20802, 'C�digo de produto inexistente');
        END IF;
    
      -- Obter a data do pen�ltimo reabastecimento do produto nessa m�quina
        SELECT min(data) INTO data_inicio
        FROM (
        SELECT v.data
        FROM Abastece a,Abastecimento ab, Compartimento c, Viagem vi, Visita v
        WHERE a.idCompartimento = c.idCompartimento
          AND ab.idViagem = vi.idViagem
          AND ab.idabastecimento = a.idabastecimento
          AND vi.idViagem = v.idViagem
          AND c.idMaquina = id_maquina
          AND c.idProduto = id_produto
        ORDER BY v.data DESC
      )
      WHERE ROWNUM = 2;
    
      -- Se n�o houver pen�ltimo reabastecimento, retorna 0
      IF data_inicio IS NULL THEN
            RETURN 0;
      END IF;
    
      -- Calcular total vendido desde essa data
      SELECT COUNT(*) INTO total_vendido
      FROM Venda v
      JOIN Compartimento c ON v.idCompartimento = c.idCompartimento
      WHERE c.idMaquina = id_maquina
        AND c.idProduto = id_produto
        AND v.data >= data_inicio;
    
      -- Calcular n�mero de dias
      dias := TRUNC(SYSDATE - data_inicio);
      IF dias < 1 THEN
            dias := 1;
      END IF;
    
      -- Calcular m�dia
      media := total_vendido / dias;
    
      RETURN media;
END;
/

SELECT quantidade_media_diaria(401, 301) FROM dual;

//d)
CREATE OR REPLACE FUNCTION data_ultimo_abastec(id_maquina IN NUMBER, id_produto IN NUMBER) RETURN DATE 
IS
  data_a DATE;
  m_existe NUMBER;
  p_existe NUMBER;
BEGIN
 -- Verifica se a m�quina existe
    SELECT COUNT(*) INTO m_existe
    FROM Maquina
    WHERE idMaquina = id_maquina;

    IF m_existe = 0 THEN
        RAISE_APPLICATION_ERROR(-20801, 'C�digo de m�quina inexistente');
    END IF;

    -- Verifica se o produto existe
    SELECT COUNT(*) INTO p_existe
    FROM Produto
    WHERE idProduto = id_produto;

    IF p_existe = 0 THEN
        RAISE_APPLICATION_ERROR(-20802, 'C�digo de produto inexistente');
    END IF;


  -- Obter a data da �ltima visita que abasteceu o produto nessa m�quina
    SELECT v.data INTO data_a
    FROM Abastece a,Abastecimento ab, Compartimento c, Viagem vi, Visita v
    WHERE a.idCompartimento = c.idCompartimento
      AND ab.idViagem = vi.idViagem
      AND ab.idabastecimento = a.idabastecimento
      AND vi.idViagem = v.idViagem
      AND c.idMaquina = id_maquina
      AND c.idProduto = id_produto
    ORDER BY v.data DESC;

  RETURN data_a;

END;
/

SELECT data_ultimo_abastec(401, 301) AS data_abastecimento FROM dual;

//e)
CREATE OR REPLACE FUNCTION distancia_entre_maquinas(idmaquina1 IN NUMBER, idmaquina2 IN NUMBER) RETURN NUMBER 
IS
  x1 NUMBER;
  y1 NUMBER;
  x2 NUMBER;
  y2 NUMBER;
  distancia NUMBER;
  m_existe NUMBER;
BEGIN
  -- Verificar se as m�quinas s�o diferentes
  IF idmaquina1 = idmaquina2 THEN
    RAISE_APPLICATION_ERROR(-20810, 'M�quinas inv�lidas. Devem ser diferentes.');
  END IF;

  -- Verificar se as maquinas existem
  SELECT COUNT(*) INTO m_existe   FROM Maquina 
  WHERE idMaquina = idmaquina1;
  
  IF m_existe = 0 THEN
    RAISE_APPLICATION_ERROR(-20801, 'C�digo de m�quina inexistente: idmaquina1');
  END IF;

  SELECT COUNT(*) INTO m_existe   FROM Maquina 
  WHERE idMaquina = idmaquina2;
  
  IF m_existe = 0 THEN
    RAISE_APPLICATION_ERROR(-20801, 'C�digo de m�quina inexistente: idmaquina2');
  END IF;

  -- Obter coordenadas
  SELECT longi, lat INTO x1, y1
  FROM Maquina
  WHERE idMaquina = idmaquina1;

  SELECT longi, lat INTO x2, y2
  FROM Maquina
  WHERE idMaquina = idmaquina2;

  distancia := distancia_linear(y1, x1, y2, x2);

  RETURN distancia;

END;
/
SELECT distancia_entre_maquinas(401, 402) AS distancia FROM dual;

//f)
CREATE OR REPLACE FUNCTION distancia_viagem(id_viagem NUMBER) RETURN NUMBER
IS
    viagem_existe NUMBER;
    distancia_total NUMBER := 0;
    lat_anterior NUMBER;
    lon_anterior NUMBER;
    lat_atual NUMBER;
    lon_atual NUMBER;
    lat_armazem NUMBER;
    lon_armazem NUMBER;
    id_armazem NUMBER;
    primeira_iteracao BOOLEAN := TRUE;
    
    -- Cursor para obter as m�quinas visitadas 
    CURSOR c1 IS
        SELECT m.lat, m.longi
        FROM Maquina m, Visita v, Requer r
        WHERE m.idMaquina = r.idMaquina and v.idviagem = r.idviagem
        AND v.idViagem = id_viagem
        ORDER BY v.data;
        
BEGIN
    -- Verificar se a viagem existe
    SELECT COUNT(*) INTO viagem_existe
    FROM Viagem
    WHERE idViagem = id_viagem;

    IF viagem_existe = 0 THEN
        RAISE_APPLICATION_ERROR(-20807, 'Viagem de abastecimento inexistente');
    END IF;
    
    -- Obter coordenadas do armaz�m de origem da viagem
    BEGIN
        SELECT a.lat, a.longi, a.idArmazem
        INTO lat_armazem, lon_armazem, id_armazem
        FROM Armazem a, Viagem v, Contem2 c, Rota r
        WHERE c.idarmazem = a.idarmazem and c.idrota = r.idrota and v.idrota = r.idrota and v.idViagem = id_viagem;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            -- Se n�o existir na viagem, usar o primeiro armaz�m dispon�vel
            SELECT lat, longi, idArmazem
            INTO lat_armazem, lon_armazem, id_armazem
            FROM Armazem
            WHERE ROWNUM = 1;
    END;
    
    -- Calcular dist�ncias entre pontos consecutivos
    FOR r IN c1 LOOP
        lat_atual := r.lat;
        lon_atual := r.longi;
        
        IF primeira_iteracao THEN
            -- calcular dist�ncia do armaz�m para a primeira m�quina
            distancia_total := distancia_total + distancia_linear(lat_armazem, lon_armazem, lat_atual, lon_atual);
            primeira_iteracao := FALSE;
        ELSE
            -- calcular dist�ncia da m�quina anterior para a atual
            distancia_total := distancia_total + distancia_linear(lat_anterior, lon_anterior, lat_atual, lon_atual);
        END IF;
        
        -- atualiza coordenadas para o loop
        lat_anterior := lat_atual;
        lon_anterior := lon_atual;
    END LOOP;
    
    -- Adicionar dist�ncia de regresso ao armaz�m
    IF NOT primeira_iteracao THEN -- tem de ter visitado pelo menos uma maquina, porque se n�o ainda estava no armazem de origem
        distancia_total := distancia_total + distancia_linear(lat_anterior, lon_anterior, lat_armazem, lon_armazem);
    END IF;
    
    RETURN ROUND(distancia_total, 3);
    
EXCEPTION
    WHEN OTHERS THEN
        IF SQLCODE = -20807 THEN
            RAISE;
        ELSE
            RAISE_APPLICATION_ERROR(-20807, 'Erro ao calcular dist�ncia da viagem');
        END IF;
END;
/

SELECT distancia_viagem(2025031105) AS distancia_total_km FROM DUAL;



//g)
CREATE OR REPLACE FUNCTION maquina_mais_proxima (id_produto NUMBER, lat NUMBER, longe NUMBER) RETURN NUMBER
IS
    p_existe NUMBER;
    codigo_maquina_proxima NUMBER;
    distancia_minima NUMBER := 999999; 
    distancia_atual NUMBER;
    
    -- Cursor para percorrer todas as m�quinas que t�m o produto dispon�vel
    CURSOR c1 IS
        SELECT DISTINCT m.idMaquina, m.lat, m.longi
        FROM Maquina m
        JOIN Compartimento c ON m.idMaquina = c.idMaquina
        WHERE c.idProduto = id_produto
        AND c.capacidadeatual > 0; 
        
BEGIN
    -- Verifica se o produto existe
    SELECT COUNT(*) INTO p_existe
    FROM Produto
    WHERE idProduto = id_produto;

    IF p_existe = 0 THEN
        RAISE_APPLICATION_ERROR(-20802, 'C�digo de produto inexistente');
    END IF;
    
    FOR r IN c1 LOOP
        distancia_atual := distancia_linear(lat, longe, r.lat, r.longi);
        
        IF distancia_atual < distancia_minima THEN
            distancia_minima := distancia_atual;
            codigo_maquina_proxima := r.idMaquina;
        END IF;
    END LOOP;
    
    RETURN codigo_maquina_proxima;
    
EXCEPTION
    WHEN OTHERS THEN
        RAISE;
END;
/

SELECT maquina_mais_proxima(301, 41.1579, -8.6291) AS maquina_proxima FROM DUAL;

//h)
CREATE OR REPLACE FUNCTION prox_maquina_sem_produto (id_produto NUMBER, id_maquina NUMBER) RETURN NUMBER
IS
    p_existe NUMBER;
    m_existe NUMBER;
    maquina_origem_lat NUMBER;
    maquina_origem_long NUMBER;
    codigo_maquina_proxima NUMBER;
    min_distancia NUMBER := 999999; 
    distancia_atual NUMBER;
    
    -- Cursor para percorrer todas as m�quinas que N�O t�m o produto dispon�vel
    CURSOR c1 IS
        SELECT m.idMaquina, m.lat, m.longi
        FROM Maquina m
        WHERE m.idMaquina <> id_maquina -- Exclui a m�quina de origem
        AND m.idMaquina NOT IN (
            SELECT c.idMaquina
            FROM Compartimento c
            WHERE c.idProduto = id_produto
            AND c.capacidadeatual > 0
        );
        
BEGIN
    -- Verifica se o produto existe
    SELECT COUNT(*) INTO p_existe
    FROM Produto
    WHERE idProduto = id_produto;

    IF p_existe = 0 THEN
        RAISE_APPLICATION_ERROR(-20802, 'C�digo de produto inexistente');
    END IF;
    
    SELECT lat, longi INTO maquina_origem_lat, maquina_origem_long
    FROM Maquina
    WHERE idMaquina = id_maquina;
    
    FOR r IN c1 LOOP
        -- Calcula a dist�ncia entre a m�quina de origem e a m�quina atual
        distancia_atual := distancia_linear(maquina_origem_lat, maquina_origem_long, r.lat, r.longi);
        
        -- Se esta m�quina est� mais pr�xima que a anterior, atualiza
        IF distancia_atual < min_distancia THEN
            min_distancia := distancia_atual;
            codigo_maquina_proxima := r.idMaquina;
        END IF;
    END LOOP;
    
    RETURN codigo_maquina_proxima;
    
EXCEPTION
    WHEN OTHERS THEN
        RAISE;
END;
/

SELECT prox_maquina_sem_produto(301, 401) AS maquina_sem_produto FROM DUAL;

//i)
CREATE OR REPLACE PROCEDURE cria_viagem_abast (cod_armazem NUMBER, raio NUMBER)
IS
    existe_arm NUMBER;
    lat_arm NUMBER;
    lon_arm NUMBER;
    id_viagem_nova NUMBER;
    id_rota_nova NUMBER;
    seq_ordem NUMBER := 1;
    contador NUMBER := 0;
    
    CURSOR c1 IS
        SELECT m.idMaquina, 
               SUM(c.capacidadeMaxi - c.capacidadeatual) AS falta_total,
               m.lat, m.longi,
               distancia_linear(lat_arm, lon_arm, m.lat, m.longi) AS dist_km
        FROM Maquina m, Compartimento c
        WHERE m.idMaquina = c.idMaquina
        AND distancia_linear(lat_arm, lon_arm, m.lat, m.longi) <= raio
        AND c.capacidadeatual < c.capacidadeMaxi
        GROUP BY m.idMaquina, m.lat, m.longi
        HAVING SUM(c.capacidadeMaxi - c.capacidadeatual) > 0
        ORDER BY falta_total DESC;
        
BEGIN
    -- Valida��o do raio
    IF raio <= 0 THEN
        RAISE_APPLICATION_ERROR(-20811, 'Dist�ncia Inv�lida');
    END IF;
    
    SELECT COUNT(*) INTO existe_arm FROM Armazem WHERE idArmazem = cod_armazem;
    IF existe_arm = 0 THEN
        RAISE_APPLICATION_ERROR(-20806, 'C�digo de armaz�m inexistente');
    END IF;
    
    SELECT lat, longi INTO lat_arm, lon_arm FROM Armazem WHERE idArmazem = cod_armazem;
    
    -- Gera novo ID 
    SELECT NVL(MAX(idRota), 0) + 1 INTO id_rota_nova FROM Rota;
    
    INSERT INTO Rota (idRota, nome, quilometros) 
    VALUES (id_rota_nova, 'Rota Abastecimento ' || TO_CHAR(SYSDATE, 'DD/MM/YYYY HH24:MI'), 0);
    
    FOR r IN c1 LOOP
        EXIT WHEN contador >= 10; -- Limita a 10 m�quinas
        
        -- Inserir na tabela de liga��o (ajustar conforme sua estrutura)
        BEGIN
            INSERT INTO contem (idRota, idMaquina, ordem) 
            VALUES (id_rota_nova, r.idMaquina, seq_ordem);
        EXCEPTION
            WHEN OTHERS THEN
                -- Se a tabela n�o existir, apenas contar as m�quinas
                NULL;
        END;
        
        seq_ordem := seq_ordem + 1;
        contador := contador + 1;
    END LOOP;
    
    -- Gera novo ID
    SELECT NVL(MAX(idViagem), 0) + 1 INTO id_viagem_nova FROM Viagem;
    
    INSERT INTO Viagem (idViagem, idRota, data_hora_inicio) 
    VALUES (id_viagem_nova, id_rota_nova, SYSDATE);
    
    COMMIT;
    
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
END;
/
 
EXEC cria_viagem_abast(1, 40);

//j)
CREATE OR REPLACE PROCEDURE encomenda_produtos(cod_armazem IN NUMBER, data_inicio IN DATE)
IS
    CURSOR c1 IS
        SELECT DISTINCT p.idProduto
        FROM Produto p;

    idProduto Produto.idProduto%TYPE;
    vendas_semana NUMBER := 0;
    qtd_maquinas NUMBER := 0;
    qtd_armazem NUMBER := 0;

BEGIN
    FOR R IN c1 LOOP
        idProduto := R.idProduto;

        -- vendas desde a data
        SELECT COUNT(*) INTO vendas_semana
        FROM Venda v
        JOIN Compartimento c ON v.idCompartimento = c.idCompartimento
        WHERE c.idProduto = idProduto
        AND v.data >= data_inicio;

        -- stock atual das m�quinas
        SELECT SUM(capacidadeAtual)
        INTO qtd_maquinas
        FROM Compartimento
        WHERE idProduto = idProduto;

        -- stock atual do armaz�m
        BEGIN
            SELECT quantidadeDisp
            INTO qtd_armazem
            FROM guardam
            WHERE idProduto = idProduto
            AND idArmazem = cod_armazem;

        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                qtd_armazem := 0;
        END;

        IF qtd_maquinas + qtd_armazem < vendas_semana THEN
            BEGIN
                INSERT INTO Encomendas(idArmazem, quantidade)
                VALUES (cod_armazem, vendas_semana - qtd_maquinas - qtd_armazem);

            EXCEPTION
                WHEN OTHERS THEN
                    RAISE_APPLICATION_ERROR(-20812, 'Erro ao criar encomenda para o produto ' || idProduto);
            END;
        END IF;

    END LOOP;

EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20806, 'Erro geral ao processar encomendas.');
END;
/


//k) 
CREATE OR REPLACE PROCEDURE abastece_produto(cod_armazem NUMBER, cod_produto NUMBER, quantidade NUMBER)
IS
    verifica_prod   NUMBER;
    verifica_armz   NUMBER;
    qtd_restante    NUMBER := quantidade;
    qtd_entregar    NUMBER;
    nova_viagem     NUMBER;
    novo_abast      NUMBER;
    veiculo_disp    NUMBER;
    func_disp       NUMBER;

    CURSOR c1 IS
        SELECT idCompartimento, 
               NVL(capacidadeMaxi - capacidadeAtual,0) AS faltam
        FROM Compartimento
        WHERE idProduto = cod_produto
          AND capacidadeAtual < capacidadeMaxi
        ORDER BY faltam DESC;
BEGIN
    -- Verificar se produto existe
    SELECT COUNT(*) INTO verifica_prod
    FROM Produto
    WHERE idProduto = cod_produto;

    IF verifica_prod = 0 THEN
        RAISE_APPLICATION_ERROR(-20802, 'C�digo de produto inexistente');
    END IF;

    -- Verificar se armaz�m existe
    SELECT COUNT(*) INTO verifica_armz
    FROM Armazem
    WHERE idArmazem = cod_armazem;

    IF verifica_armz = 0 THEN
        RAISE_APPLICATION_ERROR(-20806, 'C�digo de armaz�m inexistente');
    END IF;

    IF quantidade <= 0 THEN
        RAISE_APPLICATION_ERROR(-20813, 'Quantidade inv�lida');
    END IF;

    -- Obter dados para nova viagem
    SELECT MIN(idVeiculo) INTO veiculo_disp FROM Veiculo;
    SELECT MIN(idFuncionario) INTO func_disp FROM Funcionario;
    SELECT NVL(MAX(idViagem), 0) + 1 INTO nova_viagem FROM Viagem;
    SELECT NVL(MAX(idAbastecimento), 0) + 1 INTO novo_abast FROM Abastecimento;

    INSERT INTO Viagem(idViagem, idVeiculo, idRota, data_hora_inicio, data_hora_fim, km_percorridos)
    VALUES (nova_viagem, veiculo_disp, NULL, SYSDATE, NULL, 0);

    INSERT INTO Faz(idFuncionario, idViagem)
    VALUES (func_disp, nova_viagem);

    -- Distribuir produto pelas m�quinas
    FOR R IN c1 LOOP
        EXIT WHEN qtd_restante = 0;

        qtd_entregar := LEAST(NVL(R.faltam, 0), NVL(qtd_restante, 0));

        INSERT INTO Abastecimento(idAbastecimento, idFuncionario, idViagem, quantAbastecida)
        VALUES (novo_abast, func_disp, nova_viagem, qtd_entregar);

        INSERT INTO Abastece(idAbastecimento, idCompartimento)
        VALUES (novo_abast, R.idCompartimento);

        UPDATE Compartimento
        SET capacidadeAtual = capacidadeAtual + qtd_entregar
        WHERE idCompartimento = R.idCompartimento;

        qtd_restante := NVL(qtd_restante - qtd_entregar, 0);
        novo_abast := novo_abast + 1;
    END LOOP;

EXCEPTION
    WHEN OTHERS THEN
        IF SQLCODE BETWEEN -20813 AND -20801 THEN
            RAISE;
        END IF;
END;
/   


EXEC abastece_produto(103, 304, 1);


//l)
CREATE OR REPLACE TRIGGER update_stock
    AFTER INSERT ON venda
    FOR EACH ROW
DECLARE
    stock_total NUMBER := 0;
    m_existe NUMBER;
    estado NUMBER;
BEGIN
    -- Verificar se a m�quina existe 
    SELECT COUNT(*) INTO m_existe
    FROM Maquina
    WHERE idMaquina = :NEW.IDMAQUINA;

    IF m_existe = 0 THEN
        RAISE_APPLICATION_ERROR(-20801, 'C�digo de m�quina inexistente');
    END IF;
    
    UPDATE Compartimento
    SET capacidadeatual = capacidadeatual - 1
    WHERE idCompartimento = :NEW.idCompartimento;
    
    IF SQL%ROWCOUNT = 0 THEN
        RAISE_APPLICATION_ERROR(-20804, 'M�quina sem stock do produto');
    END IF;
    
    SELECT COALESCE(SUM(capacidadeatual), 0)
    INTO stock_total
    FROM Compartimento
    WHERE idMaquina = :NEW.IDMAQUINA;
    
    -- Se a m�quina ficou completamente sem stock, mudar estado
    IF stock_total = 0 THEN
        SELECT id_estado INTO estado
        FROM estados
        WHERE UPPER(nome) = 'SEM STOCK';

        INSERT INTO Historico (DataHora, idMaquina, id_estado)
        VALUES (SYSDATE, :NEW.IDMAQUINA, estado);
    END IF;
    
EXCEPTION
    WHEN OTHERS THEN
        IF SQLCODE BETWEEN -20813 AND -20801 THEN
            RAISE;
        ELSE
            RAISE_APPLICATION_ERROR(-20802, 'Erro ao atualizar stock da m�quina');
        END IF;
END;
/

//m)
CREATE OR REPLACE TRIGGER abastece
    BEFORE INSERT OR UPDATE ON abastecimento
    FOR EACH ROW
DECLARE
    capacidade_maquina NUMBER;
    quantidade_atual NUMBER;
    id_maquina NUMBER;
    viagem_existe NUMBER;
    viagem_iniciada NUMBER;
BEGIN
    -- Quantidade inv�lida
    IF :NEW.QUANTABASTECIDA IS NULL OR :NEW.QUANTABASTECIDA <= 0 THEN
        RAISE_APPLICATION_ERROR(-20813, 'Quantidade inv�lida');
    END IF;
    
    SELECT COUNT(*)
    INTO viagem_existe
    FROM VISITA
    WHERE IDVIAGEM = :NEW.IDVIAGEM;
    
    IF viagem_existe = 0 THEN
        RAISE_APPLICATION_ERROR(-20807, 'Viagem de abastecimento inexistente');
    END IF;
    
    -- Verificar se a viagem foi iniciada
    SELECT COUNT(*)
    INTO viagem_iniciada
    FROM VIAGEM v
    JOIN VISITA vi ON vi.IDVIAGEM = v.IDVIAGEM
    WHERE vi.IDVIAGEM = :NEW.IDVIAGEM
    AND v.DATA_HORA_INICIO IS NOT NULL;
    
    IF viagem_iniciada = 0 THEN
        RAISE_APPLICATION_ERROR(-20808, 'Viagem de abastecimento ainda n�o foi iniciada');
    END IF;
    
    -- Encontrar a m�quina associada � viagem
    SELECT m.IDMAQUINA
    INTO id_maquina
    FROM MAQUINA m
    JOIN VIAGEM v ON v.IDVEICULO = m.IDMAQUINA
    JOIN VISITA vi ON vi.IDVIAGEM = v.IDVIAGEM
    WHERE vi.IDVIAGEM = :NEW.IDVIAGEM;
    
    SELECT COALESCE(CAPACIDADE_TOTAL, 0)
    INTO capacidade_maquina
    FROM MAQUINA
    WHERE IDMAQUINA = id_maquina;
    
    -- Calcular quantidade j� abastecida
    SELECT COALESCE(SUM(QUANTABASTECIDA), 0)
    INTO quantidade_atual
    FROM ABASTECIMENTO a
    JOIN VISITA v ON v.IDVIAGEM = a.IDVIAGEM
    JOIN VIAGEM vg ON vg.IDVIAGEM = v.IDVIAGEM
    WHERE vg.IDVEICULO = id_maquina
    AND a.IDABASTECIMENTO != NVL(:NEW.IDABASTECIMENTO, -1);
    
    -- Verificar se excede capacidade
    IF (quantidade_atual + :NEW.QUANTABASTECIDA) > capacidade_maquina THEN
        RAISE_APPLICATION_ERROR(-20804, 'M�quina sem stock do produto');
    END IF;
    
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20801, 'C�digo de m�quina inexistente');
    WHEN OTHERS THEN
        IF SQLCODE BETWEEN -20813 AND -20801 THEN
            RAISE;
        ELSE
            RAISE_APPLICATION_ERROR(-20813, 'Erro no abastecimento');
        END IF;
END;
/


//n) 
CREATE OR REPLACE TRIGGER update_viagem
    AFTER INSERT OR UPDATE ON abastecimento
    FOR EACH ROW
DECLARE
    cod_viagem NUMBER;
    cod_veiculo NUMBER;
BEGIN
    SELECT v.idViagem
    INTO cod_viagem
    FROM Visita v
    WHERE v.idViagem = :NEW.IDVIAGEM;
    
    SELECT vg.idVeiculo
    INTO cod_veiculo
    FROM Viagem vg
    WHERE vg.idViagem = cod_viagem;
    
    UPDATE VEICULO
    SET CAPACIDADEATUAL = CAPACIDADEATUAL - :NEW.QUANTABASTECIDA
    WHERE IDVEICULO = cod_veiculo;
    
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        NULL;
    WHEN OTHERS THEN
        RAISE;
END;
/

//o)
CREATE or replace function distancia_linear(LAT1  NUMBER,LON1  NUMBER,LAT2  NUMBER,LON2  NUMBER) 
RETURN NUMBER
IS
    R NUMBER := 6371; -- Raio da Terra em Kms
    PI CONSTANT NUMBER := 3.141592653589793;
    D_LAT NUMBER ;
    D_LON NUMBER ;
    A NUMBER ;
    D NUMBER ;
BEGIN
    D_LAT := (LAT2 - LAT1) * PI / 180;
    D_LON := (LON2 - LON1) * PI / 180;
    A := SIN(D_LAT/2) * SIN(D_LAT/2) + COS(LAT1*PI/180) * COS(LAT2*PI/180) * SIN(D_LON/2) * SIN(D_LON/2);
    D := R * (2 * ATAN2(SQRT(A), SQRT(1 - A)));
    RETURN ROUND(D,3);
END;
/   



//p)
--Rodrigo
--Esta fun��o tem como objetivo identificar m�quinas que operam de forma ineficiente, ou seja, 
--que est�o a receber muitas visitas de abastecimento mas geram pouca receita m�dia por cada visita.
CREATE OR REPLACE FUNCTION P_FUNC_2023134919(p_idmaquina IN NUMBER)
RETURN VARCHAR2
IS
    total_receita NUMBER := 0;
    num_visitas NUMBER := 0;
    media_receita NUMBER := 0;
BEGIN
    -- Total de receita da m�quina
    SELECT SUM(c.preco)
    INTO total_receita
    FROM venda v
    JOIN compartimento c ON v.idcompartimento = c.idcompartimento
    WHERE v.idmaquina = p_idmaquina;

    -- N�mero de visitas � m�quina
    SELECT COUNT(DISTINCT vi.idviagem || '-' || c.idmaquina)
    INTO num_visitas
    FROM visita vi
    JOIN viagem vg ON vi.idviagem = vg.idviagem
    JOIN compartimento c ON c.idmaquina = p_idmaquina
    WHERE c.idmaquina = p_idmaquina;

    -- Evita divis�o por zero
    IF num_visitas = 0 THEN
        RETURN 'NAO';
    END IF;

    media_receita := total_receita / num_visitas;

    IF num_visitas > 10 AND media_receita < 30 THEN
        RETURN 'SIM';
    ELSE
        RETURN 'NAO';
    END IF;
END;
/


-- Ana 
-- Verifica se uma determinada m�quina teve queda de receita nas �ltimas duas semanas, comparando a receita da semana atual com a da semana anterior. Retorna true se teve queda e false caso contr�rio.
CREATE OR REPLACE FUNCTION P_FUNC_2023141564(p_idmaquina IN NUMBER)
RETURN BOOLEAN
IS
    total_vendas_semana_atual   NUMBER := 0;
    total_vendas_semana_anterior NUMBER := 0;
BEGIN
    SELECT NVL(SUM(p.preco), 0)
    INTO total_vendas_semana_atual
    FROM Venda v, produto p, compartimento c
    WHERE v.idMaquina = p_idmaquina
      AND v.data >= TRUNC(SYSDATE) - 7
      AND v.idcompartimento = c.idcompartimento
      AND c.idproduto = p.idproduto;

    SELECT NVL(SUM(p.preco), 0)
    INTO total_vendas_semana_anterior
    FROM Venda v, produto p, compartimento c
    WHERE v.idMaquina = p_idmaquina
      AND v.data >= TRUNC(SYSDATE) - 14
      AND v.data < TRUNC(SYSDATE) - 7
      AND v.idcompartimento = c.idcompartimento
      AND c.idproduto = p.idproduto;

    RETURN total_vendas_semana_atual < total_vendas_semana_anterior;

EXCEPTION
    WHEN OTHERS THEN
        RETURN FALSE;
END;
/


-- Gabriel
-- Esta fun��o recebe o idMaquina como par�metro e devolve uma categoria de desempenho da m�quina com base na sua receita m�dia por visita, esta fun��o ajuda a avaliar o desempenho de cada m�quina individualmente.
CREATE OR REPLACE FUNCTION P_FUNC_2023133076(p_idmaquina IN NUMBER)
RETURN VARCHAR2
IS
    total_receita NUMBER := 0;
    num_visitas NUMBER := 0;
    media NUMBER := 0;
BEGIN
    -- Total da receita
    SELECT SUM(c.preco)
    INTO total_receita
    FROM venda v
    JOIN compartimento c ON v.idcompartimento = c.idcompartimento
    WHERE v.idmaquina = p_idmaquina;

    -- N�mero de visitas
    SELECT COUNT(DISTINCT vi.idviagem || '-' || c.idmaquina)
    INTO num_visitas
    FROM visita vi
    JOIN viagem vg ON vi.idviagem = vg.idviagem
    JOIN compartimento c ON c.idmaquina = p_idmaquina
    WHERE c.idmaquina = p_idmaquina;

    IF num_visitas = 0 THEN
        RETURN 'Sem dados';
    END IF;

    media := total_receita / num_visitas;

    IF media > 100 THEN
        RETURN 'Alta';
    ELSIF media >= 50 THEN
        RETURN 'M�dia';
    ELSE
        RETURN 'Baixa';
    END IF;
END;
/

SELECT P_FUNC_2023133076(402) FROM dual;


//q)
-- Rodrigo
--Procura compartimentos com n�vel de stock abaixo de um limite m�nimo e simula uma reposi��o autom�tica
CREATE OR REPLACE PROCEDURE Q_PROC_2023134919
IS
    limite_min NUMBER := 3; -- Limite m�nimo de stock
BEGIN
    FOR comp IN (
        SELECT idcompartimento
        FROM compartimento
        WHERE capacidadeatual < limite_min
    ) LOOP
        INSERT INTO abastecimento (
            idabastecimento, idviagem, quantabastecida
        ) VALUES (
            seq_abastecimento.NEXTVAL, seq_viagem.NEXTVAL, 20
        );

        -- Atualizar o stock do compartimento
        UPDATE compartimento
        SET capacidadeatual = capacidadeatual + 20
        WHERE idcompartimento = comp.idcompartimento;
    END LOOP;
END;
/

-- Ana 
--Gerar um ranking dos produtos mais vendidos por m�quina, inserindo os resultados numa tabela chamada top_produtos_maquina. Este procedimento permite saber quais produtos t�m mais e menos sa�da por m�quina.
CREATE TABLE top_produtos_maquina (
    idMaquina NUMBER,
    idProduto NUMBER,
    total_vendido NUMBER
);
CREATE OR REPLACE PROCEDURE Q_PROC_2023141564 IS
BEGIN
    DELETE FROM top_produtos_maquina;

    -- Inserir os produtos por ordem dos mais vendidos por m�quina
    INSERT INTO top_produtos_maquina (idMaquina, idProduto, total_vendido)
    SELECT c.idMaquina, c.idProduto, count(*) AS total_vendido
    FROM Venda v
    JOIN Compartimento c ON v.idCompartimento = c.idCompartimento
    GROUP BY c.idMaquina, c.idProduto
    ORDER BY c.idMaquina, total_vendido DESC;

    COMMIT;
    
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
END;
/


-- Gabriel
-- Este procedimento identifica m�quinas que n�o registaram nenhuma venda nos �ltimos X dias (par�metro passado � fun��o) e regista essa informa��o numa tabela auxiliar chamada maquinas_inativas. Isso permite gerar alertas e an�lises de inatividade.
CREATE TABLE maquinas_inativas (
    idMaquina NUMBER,
    data_registo DATE
);
CREATE OR REPLACE PROCEDURE Q_PROC_2023133076(q_dias IN NUMBER)
IS
BEGIN
    DELETE FROM maquinas_inativas;

    -- Identifica m�quinas sem vendas no intervalo definido
    INSERT INTO maquinas_inativas (idmaquina, data_registo)
    SELECT m.idmaquina, SYSDATE
    FROM maquina m
    WHERE NOT EXISTS (
        SELECT 1
        FROM venda v
        WHERE v.idmaquina = m.idmaquina
          AND v.data >= SYSDATE - q_dias
    );
END;
/

//r)
-- Rodrigo
--impedir que se registe uma nova Venda associada a uma Maquina que n�o esteja operacional.
CREATE OR REPLACE TRIGGER R_TRIG_2023134919
BEFORE INSERT ON Venda
FOR EACH ROW
DECLARE
    estado NUMBER;
BEGIN
    -- Obter o �ltimo estado (ID) da m�quina
    SELECT h.id_estado
    INTO estado
    FROM Historico h
    WHERE h.idMaquina = :NEW.idMaquina
    AND ROWNUM = 1
    ORDER BY h.dataHora DESC;

    -- Verifica se est� operacional (id_estado = 1)
    IF estado != 1 THEN
        RAISE_APPLICATION_ERROR(-20001, 'M�quina n�o est� operacional. Venda bloqueada.');
    END IF;
END;
/

-- Ana 
-- Ap�s a inser��o de um novo abastecimento, o trigger ir� atualizar o total abastecido para a m�quina correspondente. Isso mant�m o total abastecido de cada m�quina sempre atualizado.
ALTER TABLE Maquina ADD total_abastecido NUMBER DEFAULT 0;

CREATE OR REPLACE TRIGGER R_TRIG_2023141564
AFTER INSERT ON Abastece
FOR EACH ROW
DECLARE
    id_Maquina NUMBER;
    quantAbastecida NUMBER;
BEGIN
    -- Descobre a m�quina atrav�s do compartimento
    SELECT idMaquina
    INTO id_Maquina
    FROM Compartimento
    WHERE idCompartimento = :NEW.idCompartimento;

    SELECT quantAbastecida
    INTO quantAbastecida
    FROM Abastecimento
    WHERE idAbastecimento = :NEW.idAbastecimento;

    -- Atualiza o total abastecido na m�quina
    UPDATE Maquina
    SET total_abastecido = total_abastecido + quantAbastecida
    WHERE idMaquina = id_Maquina;
END;
/



-- Gabriel
-- Este trigger impede que uma venda seja inserida se o compartimento associado n�o tiver stock suficiente.
CREATE OR REPLACE TRIGGER R_TRIG_2023133076
BEFORE INSERT ON venda
FOR EACH ROW
DECLARE
    stock NUMBER;
BEGIN
    SELECT capacidadeatual INTO stock
    FROM compartimento
    WHERE idCompartimento = :NEW.idCompartimento;

    IF stock <= 0 THEN
        RAISE_APPLICATION_ERROR(-20804, 'Compartimento sem stock do produto');
    END IF;
END;

