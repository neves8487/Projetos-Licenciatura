function alinea_a()

clear all; close all;

% Caminho da pasta com as imagens
folder = 'start';

% Nomes das classes (6 formas geométricas)
classes = {'circle','kite','parallelogram','square','trapezoid','triangle'};
numClasses = length(classes);
numImgsPerClass = 5;          % 5 imagens por classe
imgSize = [32 32];            % Tamanho fixo para as imagens

% Inicialização dos vetores de dados e etiquetas
dados = [];       % Vetor com os dados de entrada (imagens)
etiquetas = [];   % Vetor com as saídas esperadas (1-hot)

% (i) Leitura e binarização das imagens
for i = 1:numClasses
    pastaClasse = fullfile(folder, classes{i});
    imagens = dir(fullfile(pastaClasse, '*.png')); % Lê arquivos .png
    
    for j = 1:min(numImgsPerClass, length(imagens))
        img = imread(fullfile(pastaClasse, imagens(j).name));
        
        % Converter para escala de cinza se a imagem for RGB
        if size(img,3) == 3
            img = rgb2gray(img);
        end
        
        % Redimensionar e binarizar a imagem
        img = imresize(img, imgSize);
        img = imbinarize(img);
        
        % Vetorizar e adicionar aos dados
        dados = [dados, img(:)];
        
        % Criar vetor 1-hot para a classe
        etiq = zeros(numClasses,1);
        etiq(i) = 1;
        etiquetas = [etiquetas, etiq];
    end
end

%% (ii) Criar e treinar rede com 1 camada e 10 neurónios
net = feedforwardnet(10);
net.trainFcn = 'trainlm';  % Função de treino

% Definir funções de ativação
net.layers{1}.transferFcn = 'tansig';   % Oculta
net.layers{2}.transferFcn = 'purelin';  % Saída

% Usar todos os dados para treino
net.divideParam.trainRatio = 1.0;
net.divideParam.valRatio = 0.0;
net.divideParam.testRatio = 0.0;

% Definir número de épocas 
net.trainParam.epochs = 100;

% Treinar a rede
net = train(net, dados, etiquetas);

% Obter a saída da rede
saida = net(dados);

% Calcular precisão
r = 0;
for i = 1:size(saida,2)
    [~, pred] = max(saida(:,i));     % Classe predita
    [~, real] = max(etiquetas(:,i)); % Classe real
    if pred == real
        r = r + 1;
    end
end

% Mostrar precisão obtida
fprintf('Precisão com topologia inicial (10 neurónios): %.2f%%\n', r/size(saida,2)*100);

% Mostrar matriz de confusão
figure;
plotconfusion(etiquetas, saida);
title('Rede Inicial');

%% (iii) Testar outras topologias (mais neurónios/camadas)
camadas = [1, 2];               % Testar com 1 ou 2 camadas
neuronios = [5, 10, 15];        % Testar diferentes quantidades de neurónios

resultados = [];                % Guardar resultados (camadas, neurónios, precisão)

for c = camadas
    for n = neuronios
        % Criar rede com a topologia atual
        if c == 1
            net = feedforwardnet(n);
        else
            net = feedforwardnet([n n]);
        end

        net.trainFcn = 'trainlm';  % Função de treino

        % Funções de ativação
        for k = 1:c
            net.layers{k}.transferFcn = 'tansig'; % Ocultas
        end
        net.layers{end}.transferFcn = 'purelin';  % Saída

        % Usar todos os dados para treino
        net.divideParam.trainRatio = 1.0;
        net.divideParam.valRatio = 0.0;
        net.divideParam.testRatio = 0.0;
        net.trainParam.epochs = 100;

        % Treinar rede
        net = train(net, dados, etiquetas);
        saida = net(dados);

        % Calcular precisão
        r = 0;
        for i = 1:size(saida,2)
            [~, pred] = max(saida(:,i));
            [~, real] = max(etiquetas(:,i));
            if pred == real
                r = r + 1;
            end
        end
        acc = r / size(saida,2) * 100;

        % Mostrar resultado no terminal
        fprintf('Camadas: %d | Neurónios: %d -> Precisão: %.2f%%\n', c, n, acc);

        % Guardar resultado
        resultados = [resultados; c, n, acc];
    end
end

% Guardar resultados num ficheiro Excel
cabecalho = {'Camadas', 'Neuronios', 'Precisao (%)'};
writecell(cabecalho, 'resultados_alineaA.xlsx', 'Sheet', 1, 'Range', 'A1');
writematrix(resultados, 'resultados_alineaA.xlsx', 'Sheet', 1, 'Range', 'A2');
