function alinea_b()

clear; clc; close all;

classes = {'circle', 'kite', 'parallelogram', 'square', 'trapezoid', 'triangle'};
numClasses = numel(classes);
imgsPerClass = 50;
imgSize = [32, 32];
inputData = [];
targetData = [];

% -----------------------------
% leitura e conversao das imagens
% -----------------------------
for i = 1:numClasses
    folder = fullfile('train', classes{i});
    files = [dir(fullfile(folder, '*.png')); dir(fullfile(folder, '*.jpg'))];

    for j = 1:min(imgsPerClass, length(files))
        img = imread(fullfile(folder, files(j).name));
        if size(img,3) == 3
            img = rgb2gray(img);
        end
        img = imbinarize(imresize(img, imgSize));
        inputData(:, end+1) = img(:);
        t = zeros(numClasses,1); t(i) = 1;
        targetData(:, end+1) = t;
    end
end

% -----------------------------
% rede
% -----------------------------
hiddenLayerSize = 10;
trainingFunction = 'trainlm';
hiddenActivation = 'tansig';
outputActivation = 'purelin';
numExecutions = 10;  % Número de execuções para selecionar as 3 melhores

results = {};  % Armazenar resultados

% -----------------------------
% execuçao e avaliaçao
% -----------------------------
for exec = 1:numExecutions
    fprintf('\nExecução %d de %d\n', exec, numExecutions);

    % Definir e configurar a rede
    net = feedforwardnet(hiddenLayerSize, trainingFunction);
    net.layers{1}.transferFcn = hiddenActivation;
    net.layers{2}.transferFcn = outputActivation;
    net.divideParam.trainRatio = 0.9;
    net.divideParam.valRatio = 0.05;
    net.divideParam.testRatio = 0.05;
    net.trainParam.epochs = 100;

    % Treino
    [net, tr] = train(net, inputData, targetData);

    % Avaliação GLOBAL 
    outAll = net(inputData);
    acertosTotal = 0;
    for i = 1:size(outAll,2)
        [~, pred] = max(outAll(:,i));
        [~, real] = max(targetData(:,i));
        if pred == real
            acertosTotal = acertosTotal + 1;
        end
    end
    accTotal = acertosTotal / size(outAll,2) * 100;
    fprintf('Precisão GLOBAL (execução %d): %.2f%%\n', exec, accTotal);

    % Avaliação no conjunto de teste
    testInputs = inputData(:, tr.testInd);
    testTargets = targetData(:, tr.testInd);
    outTest = net(testInputs);

    acertosTeste = 0;
    for i = 1:size(outTest,2)
        [~, pred] = max(outTest(:,i));
        [~, real] = max(testTargets(:,i));
        if pred == real
            acertosTeste = acertosTeste + 1;
        end
    end
    accTeste = acertosTeste / size(outTest,2) * 100;
    fprintf('Precisão TESTE (execução %d): %.2f%%\n', exec, accTeste);

    % Armazenar resultado
    results{end+1} = struct('net', net, 'testAccuracy', accTeste, 'globalAccuracy', accTotal);
end

% -----------------------------
% guardar as 3 melhores redes
% -----------------------------
[~, idxSorted] = sort(cellfun(@(r) r.testAccuracy, results), 'descend');
for i = 1:min(3, length(idxSorted))
    bestNet = results{idxSorted(i)}.net;
    filename = sprintf('best_network_%d.mat', i);
    save(filename, 'bestNet');
    fprintf('Rede %d salva como %s (Precisão: %.2f%%)\n', i, filename, results{idxSorted(i)}.testAccuracy);
end

% -----------------------------
% MATRIZ DE CONFUSÃO DA MELHOR
% -----------------------------
bestNet = results{idxSorted(1)}.net;
outAll = bestNet(inputData);
figure; plotconfusion(targetData, outAll);
title('Matriz de Confusão - Melhor Rede (Total)');

end
   