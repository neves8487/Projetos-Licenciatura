function alinea_d()
% Alinea d) – Classificar imagens desenhadas manualmente (imagens_geradas)

clc; clear; close all;

% -----------------------------
% CARREGAR AS 3 MELHORES REDES (c-iv)
% -----------------------------
bestNets = cell(1, 3);
for i = 1:3
    filename = sprintf('best_network_final_%d.mat', i);
    data = load(filename);
    varNames = fieldnames(data);
    bestNets{i} = data.(varNames{1});
end

% -----------------------------
% DEFINIÇÕES
% -----------------------------
imgSize = [32, 32];
classes = {'circle', 'kite', 'parallelogram', 'square', 'trapezoid', 'triangle'};
numClasses = numel(classes);
inputFolder = 'imagens_geradas';

% -----------------------------
% CARREGAR IMAGENS MANUAIS
% -----------------------------
inputs = [];
targets = [];
trueLabels = [];  % Para armazenar os índices das classes reais

for i = 1:numClasses
    classFolder = fullfile(inputFolder, classes{i});
    files = [dir(fullfile(classFolder, '*.png')); dir(fullfile(classFolder, '*.jpg'))];
    
    for j = 1:length(files)
        img = imread(fullfile(classFolder, files(j).name));
        if size(img, 3) == 3
            img = rgb2gray(img);
        end
        img = imbinarize(imresize(img, imgSize));
        inputs(:, end+1) = img(:);
        
        t = zeros(numClasses, 1);
        t(i) = 1;
        targets(:, end+1) = t;
        trueLabels(end+1) = i;  % Guardar o índice da classe
    end
end

% -----------------------------
% CLASSIFICAR E ANALISAR RESULTADOS
% -----------------------------
for i = 1:3
    net = bestNets{i};
    output = net(inputs);
    
    [~, predictedLabels] = max(output, [], 1);
    [~, actualLabels] = max(targets, [], 1);
    
    % Precisão global
    accuracy = sum(predictedLabels == actualLabels) / length(actualLabels) * 100;
    fprintf('\n==== Rede %d ====\n', i);
    fprintf('Precisão global nas imagens desenhadas: %.2f%%\n', accuracy);
    
    % Precisão por classe
    for c = 1:numClasses
        idx = find(actualLabels == c);
        correct = sum(predictedLabels(idx) == c);
        total = length(idx);
        accClass = (correct / total) * 100;
        fprintf('  %12s: %.2f%% (%d/%d)\n', classes{c}, accClass, correct, total);
    end
    
    % Matriz de Confusão
    figure;
    plotconfusion(targets, output);
    title(sprintf('Matriz de Confusão - Rede %d (imagens manuais)', i));
end

end
