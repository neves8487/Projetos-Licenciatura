function alinea_c()
% Estudo das melhores redes neuronais treinadas com todas as imagens
% (pastas start, train, test).

clear; clc; close all;

% -----------------------------
% CARREGAR AS MELHORES REDES TREINADAS DE b)
% -----------------------------
bestNets = cell(1, 3); % Para armazenar as melhores redes
for i = 1:3
    filename = sprintf('best_network_%d.mat', i); % Nome dos ficheiros salvos
    load(filename, 'bestNet');

    bestNets{i} = bestNet;
end

imgSize = [32, 32];
classes = {'circle', 'kite', 'parallelogram', 'square', 'trapezoid', 'triangle'};
numClasses = numel(classes);
folders = {'start', 'train', 'test'};

% ===================================================
% ALÍNEA c-i: AVALIAR SEM TREINO COM IMAGENS DE TEST
% ===================================================
fprintf('\n===== ALÍNEA c-i: Avaliação sem treino (pasta test) =====\n');

inputsTest = [];
targetsTest = [];

for classIdx = 1:numClasses
    classFolder = fullfile('test', classes{classIdx});
    files = [dir(fullfile(classFolder, '*.png')); dir(fullfile(classFolder, '*.jpg'))];
    
    for fileIdx = 1:length(files)
        img = imread(fullfile(classFolder, files(fileIdx).name));
        if size(img, 3) == 3
            img = rgb2gray(img);
        end
        img = imbinarize(imresize(img, imgSize));
        inputsTest(:, end+1) = img(:);
        
        t = zeros(numClasses, 1);
        t(classIdx) = 1;
        targetsTest(:, end+1) = t;
    end
end

for i = 1:3
    net = bestNets{i};
    
    outTest = net(inputsTest);
    [~, predictedLabels] = max(outTest, [], 1);
    [~, actualLabels] = max(targetsTest, [], 1);
    
    accuracy = sum(predictedLabels == actualLabels) / length(actualLabels) * 100;
    fprintf('Rede %d - Precisão (sem treino) na pasta TEST: %.2f%%\n', i, accuracy);
    
    figure;
    plotconfusion(targetsTest, outTest);
    title(sprintf('Matriz de Confusão - Rede %d (sem treino, test)', i));
end

% ===================================================
% ALÍNEA c-ii: TREINO SÓ COM IMAGENS DA PASTA TEST
% ===================================================
fprintf('\n===== ALÍNEA c-ii: Treino com imagens da pasta TEST =====\n');

for i = 1:3
    net = bestNets{i}; % Rede base (copiar para nova var)

    % Treinar com as imagens da pasta test
    [net, ~] = train(net, inputsTest, targetsTest);
    
    fprintf('\nRede %d - Após treino com pasta TEST:\n', i);
    
    % Avaliar em cada pasta (start, train, test)
    for folderName = folders
        folder = folderName{1};
        inputsFolder = [];
        targetsFolder = [];
        
        for classIdx = 1:numClasses
            classFolder = fullfile(folder, classes{classIdx});
            files = [dir(fullfile(classFolder, '*.png')); dir(fullfile(classFolder, '*.jpg'))];
            
            for fileIdx = 1:length(files)
                img = imread(fullfile(classFolder, files(fileIdx).name));
                if size(img, 3) == 3
                    img = rgb2gray(img);
                end
                img = imbinarize(imresize(img, imgSize));
                inputsFolder(:, end+1) = img(:);
                
                t = zeros(numClasses, 1);
                t(classIdx) = 1;
                targetsFolder(:, end+1) = t;
            end
        end
        
        % Avaliação
        out = net(inputsFolder);
        [~, pred] = max(out, [], 1);
        [~, actual] = max(targetsFolder, [], 1);
        acc = sum(pred == actual) / length(actual) * 100;
        fprintf('Precisão na pasta %s: %.2f%%\n', folder, acc);
        
        % Matriz de confusão
        figure;
        plotconfusion(targetsFolder, out);
        title(sprintf('Confusão - Rede %d (treinada com test, avaliada em %s)', i, folder));
    end
end

% ===================================================
% ALÍNEA c-iii: TREINO COM TODAS AS IMAGENS
% ===================================================
fprintf('\n===== ALÍNEA c-iii: Treino com todas as imagens =====\n');

allDataInputs = [];
allDataTargets = [];

for f = 1:numel(folders)
    folder = folders{f};
    for iClass = 1:numClasses
        classFolder = fullfile(folder, classes{iClass});
        files = [dir(fullfile(classFolder, '*.png')); dir(fullfile(classFolder, '*.jpg'))];
        
        for j = 1:length(files)
            img = imread(fullfile(classFolder, files(j).name));
            if size(img, 3) == 3
                img = rgb2gray(img);
            end
            img = imbinarize(imresize(img, imgSize));
            allDataInputs(:, end+1) = img(:);
            
            t = zeros(numClasses, 1);
            t(iClass) = 1;
            allDataTargets(:, end+1) = t;
        end
    end
end

for i = 1:3
    net = bestNets{i};
    
    [net, ~] = train(net, allDataInputs, allDataTargets);
    
    fprintf('\nRede %d - Treinada com TODAS as imagens:\n', i);
    
    % Precisão Global
    outAll = net(allDataInputs);
    [~, predAll] = max(outAll, [], 1);
    [~, actualAll] = max(allDataTargets, [], 1);
    accAll = sum(predAll == actualAll) / length(actualAll) * 100;
    fprintf('Precisão Global: %.2f%%\n', accAll);
    
    % Avaliar em start, train, test
    for folderName = folders
        folder = folderName{1};
        inputsFolder = [];
        targetsFolder = [];
        
        for classIdx = 1:numClasses
            classFolder = fullfile(folder, classes{classIdx});
            files = [dir(fullfile(classFolder, '*.png')); dir(fullfile(classFolder, '*.jpg'))];
            
            for fileIdx = 1:length(files)
                img = imread(fullfile(classFolder, files(fileIdx).name));
                if size(img, 3) == 3
                    img = rgb2gray(img);
                end
                img = imbinarize(imresize(img, imgSize));
                inputsFolder(:, end+1) = img(:);
                
                t = zeros(numClasses, 1);
                t(classIdx) = 1;
                targetsFolder(:, end+1) = t;
            end
        end
        
        % Avaliação
        out = net(inputsFolder);
        [~, pred] = max(out, [], 1);
        [~, actual] = max(targetsFolder, [], 1);
        acc = sum(pred == actual) / length(actual) * 100;
        fprintf('Precisão na pasta %s: %.2f%%\n', folder, acc);
        
        figure;
        plotconfusion(targetsFolder, out);
        title(sprintf('Confusão - Rede %d (treinada com tudo, avaliada em %s)', i, folder));
    end
    
    % ===================================================   
    % ALÍNEA c-iv: GUARDAR REDES FINAIS
    % ===================================================
    filename = sprintf('best_network_final_%d.mat', i);
    save(filename, 'net');  % Corrigido: salvar variável net
    fprintf('Rede %d salva como %s\n', i, filename);
end
