/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tp_id;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.sf.saxon.s9api.SaxonApiException;
import net.sf.saxon.s9api.XdmItem;
import net.sf.saxon.s9api.XdmValue;


public class Xpath {

    static ArrayList<String> info_rel(String pesquisa) throws FileNotFoundException, IOException, SaxonApiException {
    ArrayList<String> resultados = new ArrayList<>();
    // Transformar a string de pesquisa em minúsculas
    String pesquisaLower = pesquisa.toLowerCase();

    // Expressões XPath modificadas para serem case-insensitive
    String xp1 = "//pais[lower-case(@nome)='" + pesquisaLower + "']/capital";
    String xp2 = "//pais[lower-case(@nome)='" + pesquisaLower + "']/area";
    String xp3 = "//pais[lower-case(@nome)='" + pesquisaLower + "']/populacao";
    String xp4 = "//pais[lower-case(@nome)='" + pesquisaLower + "']/flag";

    XdmValue res1 = XPathFunctions.executaXpath(xp1, "factos.xml");
    XdmValue res2 = XPathFunctions.executaXpath(xp2, "factos.xml");
    XdmValue res3 = XPathFunctions.executaXpath(xp3, "factos.xml");
    XdmValue res4 = XPathFunctions.executaXpath(xp4, "paises.xml");

    String resultado1 = "Capital: " + XPathFunctions.listaResultado(res1);
    String resultado2 = "area: " + XPathFunctions.listaResultado(res2);
    String resultado3 = "População: " + XPathFunctions.listaResultado(res3);
    String resultado4 = "Bandeira: " + XPathFunctions.listaResultado(res4);

    resultados.add(resultado1);
    resultados.add(resultado2);
    resultados.add(resultado3);
    resultados.add(resultado4);

    return resultados;
}

    public static ArrayList<String> cidades_imp(String pesquisa) throws FileNotFoundException, IOException, SaxonApiException {
    ArrayList<String> resultados = new ArrayList<>();
    // Vamos assumir que a pesquisa deve ter o nome exato (case-sensitive)
    String xp1 = "/lista/pais[@nome='" + pesquisa + "']/cidades_importantes/cidade";
    XdmValue res1 = XPathFunctions.executaXpath(xp1, "factos.xml");
    for (XdmItem item : res1) {
        resultados.add(item.getStringValue());
    }
    return resultados;
}

    
    public static ArrayList<String> paisesComPopulacaoMaiorQue(int minPopulacao) throws FileNotFoundException, IOException, SaxonApiException {
    ArrayList<String> resultados = new ArrayList<>();
    // XPath com a comparação direta do valor numérico
    String xp = "/lista/pais[populacao > " + minPopulacao + "]/@nome";
    XdmValue res = XPathFunctions.executaXpath(xp, "factos.xml");
    for (XdmItem item : res) {
        resultados.add(item.getStringValue());
    }
    return resultados;
}

    

    /*public static String mais_pop() throws FileNotFoundException, IOException, SaxonApiException {
        String xp1 = "//pais[number(população) = max(//pais/number(população))]/@nome";
        
        XdmValue res1 = XPathFunctions.executaXpath(xp1, "factos.xml");
        System.out.println(res1);
        String resultado = XPathFunctions.listaResultado(res1);
        System.out.println(resultado);
        return resultado;
    }*/
    
    public static ArrayList<String> paisesComReligiao(String religiao) throws FileNotFoundException, IOException, SaxonApiException {
    ArrayList<String> resultados = new ArrayList<>();
    String religiaoLower = religiao.toLowerCase();

    // XPath para encontrar países onde alguma religião (convertida para lower-case) corresponde ao que foi pesquisado
    String xp = "//pais[religioes/religiao[lower-case(.)='" + religiaoLower + "']]/@nome";
    XdmValue paises = XPathFunctions.executaXpath(xp, "factos.xml");

    for (XdmItem item : paises) {
        resultados.add(item.getStringValue());
    }

    return resultados;
}
        
    

public static ArrayList<String> todasAsCapitais() throws FileNotFoundException, IOException, SaxonApiException {
    ArrayList<String> resultados = new ArrayList<>();

    // XPath para obter o nome de todas as capitais
    String xp = "//pais/capital";
    XdmValue capitais = XPathFunctions.executaXpath(xp, "factos.xml");

    for (XdmItem item : capitais) {
        resultados.add(item.getStringValue());
    }

    return resultados;
}
    
    public static ArrayList<String> paisesComCasosCovidEntre(int min, int max) throws FileNotFoundException, IOException, SaxonApiException {
    ArrayList<String> resultados = new ArrayList<>();

    String xp = "//pais[casos_covid >= " + min + " and casos_covid <= " + max + "]/@nome";
    XdmValue paises = XPathFunctions.executaXpath(xp, "factos.xml");

    for (XdmItem item : paises) {
        resultados.add(item.getStringValue());
    }

    return resultados;
}
            

    
}
