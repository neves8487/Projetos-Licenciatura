/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.tp_id;

import java.awt.Frame;
import java.io.IOException;
import java.util.ArrayList;
import net.sf.saxon.s9api.SaxonApiException;
import net.sf.saxon.s9api.XdmValue;
import org.jdom2.Document;


public class Tp1 {

    public static void main(String[] args) throws IOException, SaxonApiException {
        
        FramePAIS frame = new FramePAIS();
        frame.setVisible(true);
        
        /*String pais="espanha";
        System.out.println("Nome: " + Wrappers.obtem_nome(pais));
        System.out.println("Continente: " + Wrappers.obtem_continente(pais));
        System.out.println("Presidente: " + Wrappers.obtem_presidente(pais));
        System.out.println("Flag: " + Wrappers.obtem_flag(pais));
        System.out.println("Capital: " + Wrappers.obtem_capital(pais));
        System.out.println("População: " + Wrappers.obtem_pop(pais));
        System.out.println("Área: " + Wrappers.obtem_area(pais));
        System.out.println("Cidades: " + Wrappers.obtem_citys(pais));
        System.out.println("Línguas oficiais: " + Wrappers.obtem_linguas(pais));
        System.out.println("Vizinhos: " + Wrappers.obtem_vizinhos(pais));
        System.out.println("Densidade populacional: " + Wrappers.obtem_densidade_populacional(pais));
        System.out.println("Religiões: " + Wrappers.obtem_religioes(pais));
        System.out.println("Casos de COVID: " + Wrappers.obtem_casos_covid(pais));*/
        
        
    }

    public static Pais criaPais(String pesquisa) throws IOException, SaxonApiException {
        String xp = "//pais[@nome='" + pesquisa + "']";
        XdmValue res = null;
        res = XPathFunctions.executaXpath(xp, "paises.xml");
        if (res == null || res.size() == 0) {
            String resultado1 = Wrappers.obtem_nome(pesquisa);
            String resultado2 = Wrappers.obtem_continente(pesquisa);
            String resultado3 = Wrappers.obtem_presidente(pesquisa);
            String resultado4 = Wrappers.obtem_flag(pesquisa);
            String resultado5 = Wrappers.obtem_capital(pesquisa);
            String resultado6 = Wrappers.obtem_pop(pesquisa);
            String resultado7 = Wrappers.obtem_area(pesquisa);
            String resultado8 = Wrappers.obtem_densidade_populacional(pesquisa);
            String resultado9 = Wrappers.obtem_casos_covid(pesquisa);
            
            
            ArrayList<String> citys = Wrappers.obtem_citys(pesquisa);
            ArrayList<String> vizinhos = Wrappers.obtem_vizinhos(pesquisa);
            ArrayList<String> linguas_ofc = Wrappers.obtem_linguas(pesquisa);
            ArrayList<String> religioes = Wrappers.obtem_religioes(pesquisa);
            
            Pais p = new Pais(pesquisa, resultado2, resultado3, resultado4, resultado5, resultado6, resultado7, resultado8, resultado9, citys, vizinhos, linguas_ofc, religioes);
            return p;
        }
            
            
        return null;
    
    }
    

        
    
}
