package com.mycompany.tp_id;

import java.util.List;
import org.jdom2.Attribute;
import org.jdom2.Document;
import org.jdom2.Element;

public class ModeloXML {

    public static Document adicionaPais(Pais p, Document doc) {
        Element raiz;
        if (doc == null) {
            raiz = new Element("lista");
            doc = new Document(raiz);
        } else {
            raiz = doc.getRootElement();
        }

        Element pais = new Element("pais");
        pais.setAttribute(new Attribute("nome", p.getNome()));
        pais.addContent(new Element("continente").addContent(p.getContinente()));
        pais.addContent(new Element("presidente").addContent(p.getPresidente()));
        pais.addContent(new Element("flag").addContent(p.getFlag()));

        raiz.addContent(pais);
        return doc;
    }

    public static Document adicionaFactos(Pais p, Document doc) {
    Element raiz;
    if (doc == null) {
        raiz = new Element("lista");
        doc = new Document(raiz);
    } else {
        raiz = doc.getRootElement();
    }

    Element pais = new Element("pais");
    pais.setAttribute("nome", p.getNome());

    pais.addContent(new Element("capital").addContent(p.getCapital()));
    pais.addContent(new Element("populacao").addContent(p.getPopulacao()));
    pais.addContent(new Element("area").addContent(p.getArea()));
    pais.addContent(new Element("densidade_populacional").addContent(p.getDensidadePopulacional()));
    pais.addContent(new Element("casos_covid").addContent(p.getCasosCovid()));

    Element cidades = new Element("cidades_importantes");
    for (String c : p.getCidades_pop()) {
        cidades.addContent(new Element("cidade").addContent(c));
    }
    pais.addContent(cidades);

    Element idiomas = new Element("idiomas_oficiais");
    for (String i : p.getIdiomas_ofc()) {
        idiomas.addContent(new Element("idioma").addContent(i));
    }
    pais.addContent(idiomas);

    Element religioes = new Element("religioes");
    for (String r : p.getReligioes()) {
        religioes.addContent(new Element("religiao").addContent(r));
    }
    pais.addContent(religioes);

    Element vizinhos = new Element("paises_na_fronteira");
    for (String v : p.getVizinhos()) {
        vizinhos.addContent(new Element("pais_vizinho").addContent(v));
    }
    pais.addContent(vizinhos);

    raiz.addContent(pais);
    return doc;
}


    public static Document removePais(String procura, Document doc) {
        if (doc == null) {
            System.out.println("Documento inexistente.");
            return null;
        }

        Element raiz = doc.getRootElement();
        List<Element> todos = raiz.getChildren("pais");
        boolean found = false;

        for (Element p : todos) {
            if (p.getAttributeValue("nome").equalsIgnoreCase(procura)) {
                raiz.removeContent(p);
                System.out.println("País removido com sucesso.");
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("País não encontrado.");
        }

        return doc;
    }

    public static Document alteraCapital(String pais, String novaCapital, Document doc) {
        if (doc == null) {
            System.out.println("Documento inexistente.");
            return null;
        }

        Element raiz = doc.getRootElement();
        boolean found = false;

        for (Element p : raiz.getChildren("pais")) {
            if (p.getAttributeValue("nome").equalsIgnoreCase(pais)) {
                Element capital = p.getChild("capital");
                if (capital != null) {
                    capital.setText(novaCapital);
                } else {
                    p.addContent(new Element("capital").setText(novaCapital));
                }
                System.out.println("Capital alterada.");
                found = true;
            }
        }

        if (!found) {
            System.out.println("País não encontrado.");
            return null;
        }

        return doc;
    }

    public static Document alteraArea(String pais, String novaArea, Document doc) {
        if (doc == null) {
            System.out.println("Documento inexistente.");
            return null;
        }

        Element raiz = doc.getRootElement();
        boolean found = false;

        for (Element p : raiz.getChildren("pais")) {
            if (p.getAttributeValue("nome").equalsIgnoreCase(pais)) {
                Element area = p.getChild("area");
                if (area != null) {
                    area.setText(novaArea);
                } else {
                    p.addContent(new Element("area").setText(novaArea));
                }
                System.out.println("Área alterada.");
                found = true;
            }
        }

        if (!found) {
            System.out.println("País não encontrado.");
            return null;
        }

        return doc;
    }

    public static Document alteraPopulacao(String pais, String novaPopulacao, Document doc) {
        if (doc == null) {
            System.out.println("Documento inexistente.");
            return null;
        }

        Element raiz = doc.getRootElement();
        boolean found = false;

        for (Element p : raiz.getChildren("pais")) {
            if (p.getAttributeValue("nome").equalsIgnoreCase(pais)) {
                Element pop = p.getChild("populacao");
                if (pop != null) {
                    pop.setText(novaPopulacao);
                } else {
                    p.addContent(new Element("populacao").setText(novaPopulacao));
                }
                System.out.println("População alterada.");
                found = true;
            }
        }

        if (!found) {
            System.out.println("País não encontrado.");
            return null;
        }

        return doc;
    }

    public static Element obterPais(String nomePais, Document doc) {
        if (doc == null) return null;
        Element root = doc.getRootElement();

        for (Element pais : root.getChildren("pais")) {
            if (nomePais.equalsIgnoreCase(pais.getAttributeValue("nome"))) {
                return pais;
            }
        }
        return null;
    }
}
