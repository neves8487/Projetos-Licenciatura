/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tp_id;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Wrappers {

    
    // Função para tratar valores numéricos, removendo separadores de milhares e substituindo a vírgula por ponto como separador decimal
public static String tratarValorNumerico(String valor) {
    valor = valor.trim();  // Remove espaços em branco
    valor = valor.replaceAll("[.,](?=(\\d{3})+(?!\\d))", ""); // Remove separadores de milhares
    valor = valor.replace(',', '.');  // Substitui vírgula por ponto para decimal
    return valor;  // Retorna o valor tratado
}

// Função que obtém o nome do país a partir de uma pesquisa
public static String obtem_nome(String pesquisa) throws FileNotFoundException, IOException {
    pesquisa = pesquisa.replace(" ", "_"); // Substitui espaços por underline para compatibilidade com URL
    String link = "https://pt.wikipedia.org/wiki/"; // URL da Wikipedia em português
    HttpRequestFunctions.httpRequest1(link, pesquisa, "pais.html");  // Faz o request HTTP para obter a página HTML
    Scanner input = new Scanner(new FileInputStream("pais.html"));  // Lê o conteúdo da página HTML
    String linha;

    // Expressão regular para capturar o nome do país
    String er1 = "<h1 id=\"firstHeading\" class=\"firstHeading\" lang=\"pt\">([^<]+)</h1>";
    Pattern p1 = Pattern.compile(er1);
    Matcher m1;

    // Busca pela linha que contém o nome do país
    while (input.hasNextLine()) {
        linha = input.nextLine();
        m1 = p1.matcher(linha);
        if (m1.find()) {
            input.close();
            return m1.group(1);  // Retorna o nome do país encontrado
        }
    }
    return null;  // Retorna null se não encontrar o nome do país
}

// Função que obtém o continente do país a partir de uma pesquisa
static String obtem_continente(String pesquisa) throws FileNotFoundException, IOException {
    String link = "https://pt.db-city.com/";  // URL do DB-City
    HttpRequestFunctions.httpRequest1(link, pesquisa, "pais.html");
    Scanner ler = new Scanner(new FileInputStream("pais.html"));
    String linha;
    // Expressão regular para capturar o continente
    String er1 = "Continente</th><td><a href=\"[^\"]+\" title=\"Continente[^\"]+\">([^<]+)</a>";
    Pattern p1 = Pattern.compile(er1);
    Matcher m1;

    while (ler.hasNextLine()) {
        linha = ler.nextLine();
        m1 = p1.matcher(linha);
        if (m1.find()) {
            ler.close();
            return m1.group(1);  // Retorna o continente
        }
    }
    ler.close();
    return null;  // Retorna null se não encontrar o continente
}

// Função que obtém o nome do presidente do país a partir de uma pesquisa
static String obtem_presidente(String pesquisa) throws FileNotFoundException, IOException {
    String link = "https://pt.db-city.com/";  // URL do DB-City
    HttpRequestFunctions.httpRequest1(link, pesquisa, "pais.html");
    Scanner input = new Scanner(new FileInputStream("pais.html"));
    String linha;

    // Expressão regular para capturar o nome do presidente
    String er1 = "Presidente da República.*?<td>([^<]+)</td>";
    Pattern p1 = Pattern.compile(er1);
    Matcher m1;

    while (input.hasNextLine()) {
        linha = input.nextLine();
        m1 = p1.matcher(linha);
        if (m1.find()) {
            input.close();
            return m1.group(1);  // Retorna o nome do presidente encontrado
        }
    }
    input.close();
    return null;  // Retorna null se não encontrar o presidente
}

// Função que obtém a bandeira do país a partir de uma pesquisa
static String obtem_flag(String pesquisa) throws FileNotFoundException, IOException {
    String link = "https://pt.wikipedia.org/wiki/";  // URL da Wikipedia
    HttpRequestFunctions.httpRequest1(link, pesquisa, "pais.html");
    Scanner input = new Scanner(new FileInputStream("pais.html"));
    String linha;

    // Expressões regulares para capturar a bandeira do país
    String er1 = "title=\"Bandeira [^\"]+\"";
    String er2 = "<img[^>]*\\s+src=\"([^\"]+)\"";
    Pattern p1 = Pattern.compile(er1);
    Pattern p2 = Pattern.compile(er2);
    Matcher m1, m2;

    while (input.hasNextLine()) {
        linha = input.nextLine();
        m1 = p1.matcher(linha);
        if (m1.find()) {
            m2 = p2.matcher(linha);
            if (m2.find()) {
                input.close();
                return "https:" + m2.group(1);  // Retorna o URL da bandeira
            }
        }
    }
    return null;  // Retorna null se não encontrar a bandeira
}

// Função que obtém a capital do país a partir de uma pesquisa
static String obtem_capital(String pesquisa) throws FileNotFoundException, IOException {
    String link = "https://pt.wikipedia.org/wiki/";  // URL da Wikipedia
    HttpRequestFunctions.httpRequest1(link, pesquisa, "pais.html");

    Scanner input = new Scanner(new FileInputStream("pais.html"));
    StringBuilder html = new StringBuilder();

    // Lê o conteúdo da página HTML
    while (input.hasNextLine()) {
        html.append(input.nextLine());
    }
    input.close();

    // Expressão regular combinada para capturar o nome da capital
    String er = "<b>Capital<\\/b>.*?<a [^>]*>([^<]+)<\\/a>";
    Pattern p = Pattern.compile(er);
    Matcher m = p.matcher(html.toString());

    if (m.find()) {
        return m.group(1);  // Retorna o nome da capital
    }

    return null;  // Retorna null se não encontrar a capital
}

    

    // Função que obtém a população do país a partir de uma pesquisa
static String obtem_pop(String pesquisa) throws FileNotFoundException, IOException {
    String link = "https://pt.db-city.com/";  // URL do DB-City
    HttpRequestFunctions.httpRequest1(link, pesquisa , "pais.html");
    Scanner input = new Scanner(new FileInputStream("pais.html"));
    String linha;

    // Expressão regular para capturar a população do país
    String er1 = "(\\d{1,3}(?:\\.\\d{3})*) habitantes";
    Pattern p1 = Pattern.compile(er1);
    Matcher m1;

    while (input.hasNextLine()) {
        linha = input.nextLine();
        m1 = p1.matcher(linha);
        if (m1.find()) {
            input.close();
            return tratarValorNumerico(m1.group(1));  // Retorna a população formatada
        }
    }
    input.close();
    return null;  // Retorna null se não encontrar a população
}

// Função que obtém a área do país a partir de uma pesquisa
static String obtem_area(String pesquisa) throws FileNotFoundException, IOException {
    String link = "https://pt.db-city.com/";  // URL do DB-City
    HttpRequestFunctions.httpRequest1(link, pesquisa , "pais.html");
    Scanner input = new Scanner(new FileInputStream("pais.html"));
    String linha;

    // Expressão regular para capturar a área do país
    String er1 = "Superfície</a></th><td>([\\d,\\.]+) km²</td></tr>";
    Pattern p1 = Pattern.compile(er1);
    Matcher m1;

    while (input.hasNextLine()) {
        linha = input.nextLine();
        m1 = p1.matcher(linha);
        if (m1.find()) {
            input.close();
            return tratarValorNumerico(m1.group(1));  // Retorna a área formatada
        }
    }
    input.close();
    return null;  // Retorna null se não encontrar a área
}

// Função que obtém as principais cidades do país a partir de uma pesquisa
static ArrayList<String> obtem_citys(String pesquisa) throws FileNotFoundException, IOException {
    pesquisa = pesquisa.replace(" ", "_");  // Substitui espaços por underscore na URL
    String link = "https://pt.db-city.com/";  // URL do DB-City
    HttpRequestFunctions.httpRequest1(link, pesquisa, "pais.html");

    // Lê o conteúdo HTML inteiro numa String
    Scanner input = new Scanner(new FileInputStream("pais.html"));
    StringBuilder conteudo = new StringBuilder();
    while (input.hasNextLine()) {
        conteudo.append(input.nextLine()).append("\n");
    }
    input.close();

    ArrayList<String> lista = new ArrayList<>();

    // Limita o conteúdo até a linha de corte
    String tudo = conteudo.toString();
    int fim = tudo.indexOf("<br/>Informação disponível");
    if (fim != -1) {
        tudo = tudo.substring(0, fim);
    }

    // Expressão regular para capturar os nomes das cidades
    String er = "<a href=\"/[^\"]+\" title=\"([^\"]+)\">";
    Pattern p = Pattern.compile(er);
    Matcher m = p.matcher(tudo);

    while (m.find()) {
        String cidade = m.group(1).trim();  // Remove espaços extra ao redor do nome da cidade
        lista.add(cidade);  // Adiciona a cidade à lista
    }

    return lista;  // Retorna a lista de cidades
}

// Função que obtém as línguas oficiais do país a partir de uma pesquisa
static ArrayList<String> obtem_linguas(String pesquisa) throws FileNotFoundException, IOException {
    pesquisa = pesquisa.replace(" ", "_");  // Substitui espaços por underscore
    String link = "https://pt.db-city.com/";  // URL do DB-City
    HttpRequestFunctions.httpRequest1(link, pesquisa, "pais.html");

    // Lê o conteúdo da página HTML
    Scanner input = new Scanner(new FileInputStream("pais.html"));
    StringBuilder conteudo = new StringBuilder();
    while (input.hasNextLine()) {
        conteudo.append(input.nextLine()).append("\n");
    }
    input.close();

    ArrayList<String> linguas = new ArrayList<>();

    // Expressão regular para capturar as línguas oficiais
    String er = "<tr><th>Língua oficial</th><td>(.*?)</td></tr>";
    Pattern p = Pattern.compile(er);
    Matcher m = p.matcher(conteudo.toString());

    if (m.find()) {
        String blocoLinguas = m.group(1);  // Bloco com as línguas oficiais
        // Substitui <br/> por separador visível e divide as línguas
        String[] partes = blocoLinguas.split("<br\\s*/?>");
        for (String lingua : partes) {
            lingua = lingua.replaceAll("<.*?>", "").trim();  // Limpa tags HTML e espaços
            if (!lingua.isEmpty()) {
                linguas.add(lingua);  // Adiciona a língua à lista
            }
        }
    }

    return linguas;  // Retorna a lista de línguas
}

// Função que obtém os países vizinhos a partir de uma pesquisa
static ArrayList<String> obtem_vizinhos(String pesquisa) throws FileNotFoundException, IOException {
    pesquisa = pesquisa.replace(" ", "_");  // Substitui espaços por underscore
    String link = "https://pt.db-city.com/";  // URL do DB-City
    HttpRequestFunctions.httpRequest1(link, pesquisa, "pais.html");

    // Lê o conteúdo completo da página HTML
    Scanner input = new Scanner(new FileInputStream("pais.html"), "UTF-8");
    StringBuilder conteudo = new StringBuilder();
    while (input.hasNextLine()) {
        conteudo.append(input.nextLine()).append("\n");
    }
    input.close();

    ArrayList<String> vizinhos = new ArrayList<>();

    // Expressão regular para capturar os países vizinhos
    String er = "<h2 id=\"border\">.*?</h2>.*?<div class=\"h2content\">.*?<ol class=\"h2l\">(.*?)</ol>";
    Pattern blocoPattern = Pattern.compile(er, Pattern.DOTALL);
    Matcher blocoMatcher = blocoPattern.matcher(conteudo.toString());

    if (blocoMatcher.find()) {
        String bloco = blocoMatcher.group(1);  // Bloco com países vizinhos
        // Expressão regular para capturar os nomes dos países vizinhos
        Pattern paisPattern = Pattern.compile("title=\"([^\"]+)\"");
        Matcher paisMatcher = paisPattern.matcher(bloco);
        while (paisMatcher.find()) {
            vizinhos.add(paisMatcher.group(1).trim());  // Adiciona vizinhos à lista
        }
    }

    return vizinhos;  // Retorna a lista de países vizinhos
}

// Função que obtém a densidade populacional do país a partir de uma pesquisa
static String obtem_densidade_populacional(String pesquisa) throws FileNotFoundException, IOException {
    String link = "https://pt.db-city.com/";  // URL do DB-City
    HttpRequestFunctions.httpRequest1(link, pesquisa , "pais.html");
    Scanner input = new Scanner(new FileInputStream("pais.html"));
    String linha;

    // Expressão regular para capturar a densidade populacional
    String er1 = "Densidade populacional.*?<td>\\s*([\\d,.]+)\\s*/km²</td>";
    Pattern p1 = Pattern.compile(er1);
    Matcher m1;

    while (input.hasNextLine()) {
        linha = input.nextLine();
        m1 = p1.matcher(linha);
        if (m1.find()) {
            input.close();
            return tratarValorNumerico(m1.group(1));  // Retorna a densidade populacional formatada
        }
    }
    input.close();
    return null;  // Retorna null se não encontrar a densidade populacional
}

// Obtém lista de religiões principais no país, buscando entre <strong> na seção de religião
    static ArrayList<String> obtem_religioes(String pesquisa) throws FileNotFoundException, IOException {
        pesquisa = pesquisa.replace(" ", "_");
        String link = "https://pt.db-city.com/";
        HttpRequestFunctions.httpRequest1(link, pesquisa, "pais.html");
        Scanner input = new Scanner(new FileInputStream("pais.html"));
        StringBuilder conteudo = new StringBuilder();
        String linha;
        while (input.hasNextLine()) {
            linha = input.nextLine();
            conteudo.append(linha);
        }
        input.close();

        ArrayList<String> lista = new ArrayList<>();
        // Captura o bloco de religiões via regex DOTALL
        Pattern pSecao = Pattern.compile("<h2 id=\"religion\">.*?<ol class=\"h2l\">(.*?)</ol>", Pattern.DOTALL);
        Matcher mSecao = pSecao.matcher(conteudo.toString());

        if (mSecao.find()) {
            String secao = mSecao.group(1);
            Pattern pItem = Pattern.compile("<strong>([^<]+)</strong>");
            Matcher mItem = pItem.matcher(secao);
            while (mItem.find()) {
                lista.add(mItem.group(1).trim());
            }
        }
        return lista;
    }

    // Extrai número de casos confirmados de COVID-19, padronizando o valor numérico
    static String obtem_casos_covid(String pesquisa) throws FileNotFoundException, IOException {
        String link = "https://pt.db-city.com/";
        HttpRequestFunctions.httpRequest1(link, pesquisa , "pais.html");
        Scanner input = new Scanner(new FileInputStream("pais.html"));
        String linha;

        // Regex para “Covid-19 ... Confirmado</th><td>123.456</td>”
        Pattern p1 = Pattern.compile("Covid-19.*?<th>Confirmado</th><td>([\\d\\.]+)</td>");
        Matcher m1;

        while (input.hasNextLine()) {
            linha = input.nextLine();
            m1 = p1.matcher(linha);
            if (m1.find()) {
                input.close();
                return tratarValorNumerico(m1.group(1));
            }
        }
        input.close();
        return null;
    }
}