import "./assets/styles/App.css";
import { useState, useEffect } from "react";
import ControlPanel from "./components/control-panel/control-panel";
import Footer from "./components/footer/footer";
import GamePanel from "./components/game-panel/game-panel";
import Header from "./components/header/header";

function App() {
  const [gameStarted, setGameStarted] = useState(false);
  const [selectedLevel, setSelectedLevel] = useState("0");
  const [flagsLeft, setFlagsLeft] = useState(0);

  const handleGameStart = () => setGameStarted(!gameStarted);
  const handleLevelChange = (event) => {
    const { value } = event.currentTarget;
    setSelectedLevel(value);
  };

  const handleFlagChange = (newFlagsLeft) => {
    setFlagsLeft(newFlagsLeft);
  };

  return (
    <div id="container">
      <Header />
      <main>
        <ControlPanel
          gameStarted={gameStarted}
          selectedLevel={selectedLevel}
          onGameStart={handleGameStart}
          onLevelChange={handleLevelChange}
          flagsLeft={flagsLeft}
        />
        <GamePanel
          selectedLevel={selectedLevel}
          gameStarted={gameStarted}
          onGameStart={handleGameStart}
          handleGameStart={handleGameStart}
          handleFlagChange={handleFlagChange}
        />
      </main>
      <Footer />
    </div>
  );
}

export default App;

