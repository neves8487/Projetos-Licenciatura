import React from "react";

export default function Footer(){
    return (
        <footer>
        <p>LS © D E I S @ I S EC</p>
        </footer>
        )
}