import React, { useState, useEffect } from "react";
import "./game-panel.css";
import Cell from "../celula/celula";
import shuffleArray from "../../helpers/shuffle";

export default function GamePanel(props) {
  const [tabuleiro, setTabuleiro] = useState([]);
  const { selectedLevel, gameStarted, handleGameStart, handleFlagChange } =
    props;
  const [flagsLeft, setFlagsLeft] = useState(0);
  const [nonBombFlippedCount, setNonBombFlippedCount] = useState(0);
  const [playerInteracted, setPlayerInteracted] = useState(false); // Estado para controlar se o jogador interagiu

  useEffect(() => {
    const initializeBoard = () => {
      let NCOL, NLIN, MINES;
      switch (selectedLevel) {
        default:
          NLIN = 9;
          NCOL = 9;
          MINES = 10;
          break;
        case "2":
          NLIN = 16;
          NCOL = 16;
          MINES = 40;
          break;
        case "3":
          NLIN = 16;
          NCOL = 30;
          MINES = 99;
          break;
      }
      const opcao1 = "vazio";
      const opcao2 = "bomba";
      const newTabuleiro = new Array(NCOL * NLIN).fill(opcao1);
      for (let i = 0; i < MINES; i++) {
        newTabuleiro[i] = opcao2;
      }
      shuffleArray(newTabuleiro);
      setTabuleiro(newTabuleiro);
      setFlagsLeft(MINES);
    };

    if (gameStarted) {
      initializeBoard();
    }
  }, [gameStarted, selectedLevel]);

  const handleFlagPlacement = (isFlagPlaced) => {
    setFlagsLeft((prevFlags) => {
      const newFlags = prevFlags + (isFlagPlaced ? -1 : 1);
      return newFlags >= 0 ? newFlags : prevFlags;
    });
  };

  useEffect(() => {
    handleFlagChange(flagsLeft);
  }, [flagsLeft, handleFlagChange]);

  useEffect(() => {
    const nonBombCellsCount = tabuleiro.filter(
      (elemento) => elemento !== "bomba"
    ).length;

    if (gameStarted && playerInteracted) {
      // Verificar vitória apenas se o jogo começou e o jogador interagiu
      const allCellsFlipped = tabuleiro.every((cell) => cell !== "vazio");
      if (
        nonBombFlippedCount === nonBombCellsCount - flagsLeft &&
        allCellsFlipped
      ) {
        alert("Parabéns! Você venceu!");
        handleGameStart();
      }
    }
  }, [
    gameStarted,
    nonBombFlippedCount,
    tabuleiro,
    flagsLeft,
    handleGameStart,
    playerInteracted,
  ]);

  const calculateAdjacentBombCount = (index, NCOL, NLIN) => {
    const directions = [
      -NCOL - 1,
      -NCOL,
      -NCOL + 1,
      -1,
      1,
      NCOL - 1,
      NCOL,
      NCOL + 1,
    ];
    let bombCount = 0;

    directions.forEach((direction) => {
      const adjacentIndex = index + direction;
      const isValidIndex = adjacentIndex >= 0 && adjacentIndex < NCOL * NLIN;

      if (isValidIndex) {
        const isSameRow =
          Math.floor(index / NCOL) === Math.floor(adjacentIndex / NCOL);
        const isAdjacentRow =
          Math.abs(
            Math.floor(index / NCOL) - Math.floor(adjacentIndex / NCOL)
          ) === 1;

        if ((direction === -1 || direction === 1) && !isSameRow) return;
        if (direction !== -1 && direction !== 1 && !isAdjacentRow && !isSameRow)
          return;

        if (tabuleiro[adjacentIndex] === "bomba") {
          bombCount++;
        }
      }
    });

    return bombCount;
  };

  return (
    <section id="panel-game">
      <div
        id={
          selectedLevel === "2"
            ? "game-medio"
            : selectedLevel === "3"
            ? "game-profissional"
            : "game"
        }
      >
        {tabuleiro.map((elemento, index) => {
          const NCOL =
            selectedLevel === "3" ? 30 : selectedLevel === "2" ? 16 : 9;
          const NLIN =
            selectedLevel === "3" ? 16 : selectedLevel === "2" ? 16 : 9;

          return (
            <Cell
              key={index}
              name={elemento}
              gameStarted={gameStarted}
              handleGameStart={() => {
                setPlayerInteracted(true); // O jogador interagiu quando o jogo começou
                handleGameStart();
              }}
              id={`cell-${index}`}
              adjacentBombCount={calculateAdjacentBombCount(index, NCOL, NLIN)}
              onFlagChange={handleFlagPlacement}
              flagsLeft={flagsLeft}
              onCellFlip={() => {
                if (elemento !== "bomba") {
                  setNonBombFlippedCount((prevCount) => prevCount + 1);
                }
                setPlayerInteracted(true); // O jogador interagiu ao clicar em uma célula
              }}
            />
          );
        })}
      </div>
    </section>
  );
}
