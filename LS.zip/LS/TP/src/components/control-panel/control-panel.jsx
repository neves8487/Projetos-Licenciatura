import "./control-panel.css";
import React from "react";
import { useState, useEffect } from "react";

export default function ControlPanel(props) {
  const { gameStarted, selectedLevel, onGameStart, onLevelChange, flagsLeft } = props;
  const gameStartedClass = gameStarted ? " gameStarted" : "";
  const [segundos, setSegundos] = useState(0);

  useEffect(() => {
    let timer;
    if (gameStarted) {
      timer = setInterval(() => {
        setSegundos((prevSegundos) => prevSegundos + 1);
      }, 1000);
    } else {
      setSegundos(0);
    }

    return () => clearInterval(timer);
  }, [gameStarted]);

  return (
    <>
      <section id="panel-control">
        <h3 className="sr-only">Escolha do Nível</h3>
        <form className="form">
          <fieldset className="form-group">
            <label htmlFor="btLevel">Nível:</label>
            <select id="btLevel" onChange={onLevelChange} disabled={gameStarted}>
              <option value="0">Seleccione...</option>
              <option value="1">Fácil</option>
              <option value="2">Médio</option>
              <option value="3">Profissional</option>
            </select>
          </fieldset>
          <button type="button" id="btPlay" disabled={selectedLevel === "0"} onClick={onGameStart}>
            {!gameStarted ? "Iniciar Jogo" : "Terminar Jogo"}
          </button>
        </form>
        <div className="form-metadata">
          <dl className={`list-item left${gameStartedClass}`}>
            <dt>Tempo de Jogo:</dt>
            <dd id="gameTime">{segundos}s</dd>
          </dl>
          <dl className={`list-item left${gameStartedClass}`}>
            <dt>🚩:</dt>
            <dd id="flagsLeft">{flagsLeft}</dd>
          </dl>
        </div>
      </section>
    </>
  );
}
