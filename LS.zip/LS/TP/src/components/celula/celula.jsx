import "./celula.css";
import React, { useState, useEffect } from "react";
import {
  PLACEHOLDER_CELL_PATH,
  PLACEHOLDER_CELLBACK_PATH,
} from "../../constants";

export default function Cell(props) {
  const { name, gameStarted, handleGameStart, adjacentBombCount, onFlagChange, flagsLeft } = props;
  const [isActive, setIsActive] = useState(false);
  const [hasFlipped, setHasFlipped] = useState(false);
  const [isFlagged, setIsFlagged] = useState(false);
  const [showAdjacentBombCount, setShowAdjacentBombCount] = useState(false);
  const [flagState, setFlagState] = useState(0); // 0: Normal, 1: Flagged, 2: Question mark

  useEffect(() => {
    
    if (!gameStarted) {
      setIsActive(false);
      setHasFlipped(false);
      setIsFlagged(false); // Resetar as bandeiras quando o jogo terminar
      setShowAdjacentBombCount(false); // Resetar a exibição do número de bombas adjacentes
      setFlagState(0); // Resetar o estado da bandeira
    }
  }, [gameStarted]);

  const handleClick = () => {
    if (gameStarted && !hasFlipped) {
      setIsActive(true);
      setHasFlipped(true);
      if (name === "bomba") {
        setTimeout(() => {
          alert("bomba");
          handleGameStart();
        }, 200); // Atraso de 0.2 segundos antes de terminar o jogo para revelar bomba
      } else {
        setShowAdjacentBombCount(true); // Mostrar o número de bombas adjacentes apenas se a célula for vazia
      }
    }
  };

  const handleRightClick = (e) => {
    e.preventDefault(); // Impede o menu de contexto padrão
    if (gameStarted && !isActive) {
      if (flagState === 0 && flagsLeft > 0) {
        setIsFlagged(true);
        setFlagState(1); // Definir o estado para Bandeira
        onFlagChange(true);
      } else if (flagState === 1) {
        setIsFlagged(false);
        setFlagState(2); // Definir o estado para Ponto de interrogação
        onFlagChange(false);
      } else {
        setFlagState(0); // Definir o estado para Normal
      }
    }
  };

  return (
    <div className={`cell ${isActive ? 'flipped' : ''}`} data-logo={name} onClick={handleClick} onContextMenu={handleRightClick}>
      <img
        src={PLACEHOLDER_CELLBACK_PATH}
        className={isActive ? 'cell-front' : 'cell-back'}
        alt=""
      />
      {flagState === 1 && (
        <div className="flag">🚩</div>
      )}
      {flagState === 2 && (
        <div className="question-mark">?</div>
      )}
      {showAdjacentBombCount && adjacentBombCount > 0 && (
        <div className="adjacent-bomb-count">{adjacentBombCount}</div>
      )}
      <img
        src={PLACEHOLDER_CELL_PATH + name + ".png"}
        className={isActive ? 'cell-back' : 'cell-front'}
        alt=""
      />
    </div>
  );
}
