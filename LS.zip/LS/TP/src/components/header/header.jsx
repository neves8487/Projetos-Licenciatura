import React from "react";

export default function Header() {
  return (
    <header>
      <h2>Minesweeper</h2>
      <br />
      <h3>Linguagens Script</h3>
    </header>
  );
}
