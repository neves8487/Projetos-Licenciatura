export const CELL_IMG = [
     "bomba",
     "vazio",
     "virado",
];


export const PLACEHOLDER_CELL_PATH = "/assets/images/";
export const PLACEHOLDER_CELLBACK_PATH = `${PLACEHOLDER_CELL_PATH}virado.png`;
