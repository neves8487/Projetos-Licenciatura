#ifndef CARAVANA_H
#define CARAVANA_H

#include "Buffer.h"
using namespace std;
class Caravana {
protected:
    int id;
    int tripulantes;
    int maxtripul;
    int capacidadeCarga;
    int carga;
    int agua;
    int posX, posY;

public:
    Caravana(int id, int tripulantes,int maxtripul, int capacidadeCarga,int carga, int agua, int x, int y);
    virtual void render(Buffer& buffer) const;
    virtual void comportamentoAutonomo(const Buffer& buffer); // Comportamento autônomo
    virtual int venderMercadoria(int preco); // Vende mercadoria e retorna o lucro
    virtual void sofrerTempestade(); // Reduz tripulantes e água
    void move(const string& direction, const Buffer& buffer);
    int getPosX() const; // Retorna a posição X
    int getPosY() const; // Retorna a posição Y
    int getId() const;
    void setId(int newId);
    string getDescricao() const;

    void adicionarTripulantes(int quantidade);
    void reduzirTripulantes(int quantidade);
    int getTripulacao();
    int getCarga() const {
        return carga;
    }
    int getCapacidadeCarga() const {
        return capacidadeCarga;
    }
    int getCapacidadeTripulantes() const {
        return maxtripul;
    }


        bool adicionarMercadoria(int quantidade);
};

#endif // CARAVANA_H
