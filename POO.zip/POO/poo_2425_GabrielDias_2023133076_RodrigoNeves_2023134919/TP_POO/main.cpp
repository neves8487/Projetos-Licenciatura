#include <iostream>
#include <string>
#include <sstream>
#include "Simulador.h"
using namespace std;

int main() {
    Simulador simulador(20, 20);

    try {
        string comando;
        while (true) {
            cout << "Digite um comando";
            getline(cin, comando);

            if (comando == "sair") {
                break; // Sai do jogo
            }

            istringstream iss(comando);
            string cmd;
            iss >> cmd;
            
            if (cmd == "config") {
                string nomeFicheiro;
                if (iss >> nomeFicheiro) {
                    simulador.iniciar(nomeFicheiro); // Inicia o simulador com o arquivo de configuração especificado
                    simulador.renderizar(); // Atualiza a renderização do estado do jogo
                } else {
                    cerr << "Uso: config <nomeFicheiro>" << endl;
                }
            } else {
                simulador.processarComando(comando); // Processa o comando inserido pelo jogador
                simulador.renderizar(); // Atualiza a renderização do estado do jogo
            }
        }
    } catch (const exception& e) {
        cerr << "Erro: " << e.what() << endl;
    }

    return 0;
}