#include "CaravanaBarbara.h"
#include <cstdlib>
#include <iostream>

CaravanaBarbara::CaravanaBarbara(int x, int y)
        : Caravana(-1, 40, 40, 0, 0, 0, x, y) {}

void CaravanaBarbara::comportamentoAutonomo(const Buffer& buffer) {
    int randomDirection = std::rand() % 4;
    std::string direction;
    switch (randomDirection) {
        case 0: direction = "C"; break; // Move up
        case 1: direction = "B"; break; // Move down
        case 2: direction = "E"; break; // Move left
        case 3: direction = "D"; break; // Move right
    }
    move(direction, buffer);
}
void CaravanaBarbara::render(Buffer& buffer) const {
    buffer.setChar(posX, posY, '!');
}

void CaravanaBarbara::sofrerTempestade() {
    tripulantes -= tripulantes * 0.1; // Perde 10% dos tripulantes
    if (tripulantes < 0) tripulantes = 0;
    std::cout << "Caravana Bárbara sofreu uma tempestade e perdeu 10% dos tripulantes.\n";
}