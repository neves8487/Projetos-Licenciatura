#ifndef MAPA_H
#define MAPA_H

#include <vector>
#include <unordered_map>
#include <string>
#include "Buffer.h"
#include "Cidade.h"
#include "Caravana.h"
#include "CaravanaBarbara.h"

using namespace std;

class Mapa {
private:
    int rows, cols;
    vector<string> layout; // Representação do mapa
    unordered_map<string, int> config; // Configurações do mapa
    vector<Cidade> cidades; // Lista de cidades no mapa
    vector<Caravana> caravanas;
    vector<CaravanaBarbara> caravanasBarbaras;// Lista de caravanas no mapa

public:
    Mapa(); // Construtor, precisa ser implementado
    void loadFromFile(const std::string& filename); // Carrega o mapa de um arquivo
    void render(Buffer& buffer) const; // Renderiza o mapa no buffer
    int getMoedas() const;
    int getPrecoCaravana() const;
    int getRows() const { return rows; }
    int getCols() const { return cols; }
    const vector<Caravana>& getCaravanas() const { return caravanas; }
    const vector<CaravanaBarbara>& getCaravanasBarbaras() const { return caravanasBarbaras; }
    bool existeCidade(const string& nome) const; // Verifica se uma cidade existe
    int getPosXDaCidade(const string& nome) const; // Posição X de uma cidade
    int getPosYDaCidade(const string& nome) const; // Posição Y de uma cidade
    bool isCidade(int x, int y) const;
    int getPrecoCompraMercadoria() const; // Retorna o preço de compra de mercadoria
    int getPrecoVendaMercadoria() const; // Retorna o preço de venda de mercadoria

};

#endif // MAPA_H