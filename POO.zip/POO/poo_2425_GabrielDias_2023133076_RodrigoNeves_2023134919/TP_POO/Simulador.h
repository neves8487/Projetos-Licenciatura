#ifndef SIMULADOR_H
#define SIMULADOR_H

#include <vector>
#include <string>
#include "Mapa.h"
#include "Buffer.h"
#include "Caravana.h"
#include "CaravanaBarbara.h"
#include "CaravanaMilitar.h"
#include "CaravanaComercio.h"
#include "CaravanaSecreta.h"
#include "Cidade.h"

using namespace std;

class Simulador {
private:
    int rows, cols;
    Mapa mapa;
    Buffer buffer;
    int idCounter;
    int moedas;
    vector<Caravana> caravanas; // Aqui está a declaração da variável caravanas
    vector<CaravanaBarbara> caravanabarbara;
    int precoMercadoria;
    int precoVendaMercadoria;
    int precoCaravana;
    int precoTripulante = 1;
public:
    Simulador(int rows, int cols);
    ~Simulador();
    void iniciar(const string& configFile);
    void renderizar();
    void adicionarCaravana(Caravana caravana);
    void listarCaravanasNaCidade(const string& nomeCidade);
    void adicionarCaravanaBarbara(CaravanaBarbara caravana);
    void gastarMoedas(int quantidade);
    void processarComando(const string& comando);
    void executarTurno();
    void adicionarBarbaro(int x, int y);
    void comprarCaravana(const string& cidade, char tipo);
    void moverCaravana(int id, const string& direcao);
    const vector<Caravana>& getCaravanas() const;
    void criarTempestadeDeAreia(int x, int y, int raio);
    void comprarTripulantes(int idCaravana, int quantidade);

    void venderMercadoria(int idCaravana);
    void comprarMercadoria(int idCaravana, int quantidade);
    int getMoedas() const;
    void adicionarMoedas(int quantidade);
    void removerCaravana(const Caravana& caravana);
    void removerCaravanaBarbara(const CaravanaBarbara& caravana);

    void listarPrecos();




};

#endif // SIMULADOR_H
