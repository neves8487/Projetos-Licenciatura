#include "Caravana.h"
#include "Buffer.h"
#include <cstdlib>
#include <sstream>
using namespace std;

// Construtor da classe Caravana
Caravana::Caravana(int id, int tripulantes, int maxtripul, int capacidadeCarga, int carga, int agua, int x, int y)
        : id(id), tripulantes(tripulantes), maxtripul(maxtripul), capacidadeCarga(capacidadeCarga), carga(carga), agua(agua), posX(x), posY(y) {}

// Define o ID da caravana
void Caravana::setId(int newId) {
    id = newId;
}

// Move a caravana na direção especificada
void Caravana::move(const std::string& direction, const Buffer& buffer) {
    int newX = posX;
    int newY = posY;

    if (direction == "C" && posX > 0) newX--; // Move para cima se não estiver na borda superior
    else if (direction == "B" && posX < buffer.getRows() - 1) newX++; // Move para baixo se não estiver na borda inferior
    else if (direction == "E" && posY > 0) newY--; // Move para a esquerda se não estiver na borda esquerda
    else if (direction == "D" && posY < buffer.getCols() - 1) newY++; // Move para a direita se não estiver na borda direita
    else if (direction == "CE" && posX > 0 && posY > 0) { newX--; newY--; } // Move para cima-esquerda
    else if (direction == "CD" && posX > 0 && posY < buffer.getCols() - 1) { newX--; newY++; } // Move para cima-direita
    else if (direction == "BE" && posX < buffer.getRows() - 1 && posY > 0) { newX++; newY--; } // Move para baixo-esquerda
    else if (direction == "BD" && posX < buffer.getRows() - 1 && posY < buffer.getCols() - 1) { newX++; newY++; } // Move para baixo-direita

    // Verifica se a nova posição está dentro dos limites do mapa e não é uma montanha
    if (buffer.getChar(newX, newY) != '+' && buffer.getChar(newX, newY) != ' ') {
        posX = newX;
        posY = newY;
    }
}

// Renderiza a caravana no buffer
void Caravana::render(Buffer& buffer) const {
    char c = '0' + (id % 10);
    buffer.setChar(posX, posY, c); // Exibe o caracter no mapa
}

// Define o comportamento autônomo da caravana
void Caravana::comportamentoAutonomo(const Buffer& buffer) {
    int randomDirection = rand() % 4;
    string direction;
    switch (randomDirection) {
        case 0: direction = "C"; break; // Move para cima
        case 1: direction = "B"; break; // Move para baixo
        case 2: direction = "E"; break; // Move para a esquerda
        case 3: direction = "D"; break; // Move para a direita
    }
    move(direction, buffer);
}

// Retorna a posição X da caravana
int Caravana::getPosX() const {
    return posX;
}

// Retorna a posição Y da caravana
int Caravana::getPosY() const {
    return posY;
}

// Retorna o ID da caravana
int Caravana::getId() const {
    return id;
}

// Vende mercadoria e retorna o lucro
int Caravana::venderMercadoria(int preco) {
    int lucro = carga * preco;
    carga = 0; // Zera a capacidade de carga após a venda
    return lucro;
}

// Implementa o método sofrerTempestade
void Caravana::sofrerTempestade() {
    tripulantes -= tripulantes * 0.1; // Perde 10% dos tripulantes
    if (tripulantes < 0) tripulantes = 0;
}

// Retorna a descrição da caravana
std::string Caravana::getDescricao() const {
    ostringstream oss;
    oss << "ID: " << id << "\n"
        << "Tripulantes: " << tripulantes << "\n"
        << "Carga: " << carga << "\n"
        << "Agua: " << agua << "\n"
        << "Posicao: (" << posX << ", " << posY << ")";
    return oss.str();
}

// Adiciona tripulantes à caravana
void Caravana::adicionarTripulantes(int quantidade) {
    tripulantes += quantidade;
}

// Reduz tripulantes da caravana
void Caravana::reduzirTripulantes(int quantidade) {
    tripulantes -= quantidade;
}

// Retorna a tripulação da caravana
int Caravana::getTripulacao() {
    return tripulantes;
}

// Adiciona mercadoria à caravana
bool Caravana::adicionarMercadoria(int quantidade) {
    if (carga + quantidade > capacidadeCarga) {
        return false;  // Excede a capacidade
    }
    carga += quantidade;
    return true;  // Mercadoria adicionada com sucesso
}