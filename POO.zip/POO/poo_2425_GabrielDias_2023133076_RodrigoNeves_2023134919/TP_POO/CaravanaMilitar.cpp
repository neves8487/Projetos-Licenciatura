#include "CaravanaMilitar.h"
#include <iostream>

CaravanaMilitar::CaravanaMilitar(int id, int x, int y)
        : Caravana(id, 1, 40, 5, 0, 400, x, y) {}

void CaravanaMilitar::sofrerTempestade() {
    int tripulantesPerdidos = tripulantes * 0.1;
    tripulantes -= tripulantesPerdidos;
    std::cout << "A Caravana Militar perdeu " << tripulantesPerdidos << " tripulantes.\n";
    if (rand() % 100 < 33) {
        std::cout << "A Caravana Militar foi destruída!\n";
        tripulantes = 0;
    }
}

void CaravanaMilitar::comportamentoAutonomo(const Buffer& buffer) {
    int randomDirection = std::rand() % 4;
    std::string direction;
    switch (randomDirection) {
        case 0: direction = "C"; break; // Move up
        case 1: direction = "B"; break; // Move down
        case 2: direction = "E"; break; // Move left
        case 3: direction = "D"; break; // Move right
    }
    move(direction, buffer);
}