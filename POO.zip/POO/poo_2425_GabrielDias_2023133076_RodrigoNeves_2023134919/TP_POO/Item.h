#ifndef ITEM_H
#define ITEM_H

#include <string>
#include "Caravana.h"
#include "Simulador.h"

class Item {
protected:
    std::string nome;

public:
    Item(const std::string& nome);
    virtual ~Item() = default;

    virtual void aplicarEfeito(Caravana& caravana, Simulador& simulador) = 0; // Efeito do item
    std::string getNome() const;
};

// Subclasses de itens
class CaixaDePandora : public Item {
public:
    CaixaDePandora();
    void aplicarEfeito(Caravana& caravana, Simulador& simulador) override;
};

class ArcaDoTesouro : public Item {
public:
    ArcaDoTesouro();
    void aplicarEfeito(Caravana& caravana, Simulador& simulador) override;
};

class Jaula : public Item {
public:
    Jaula();
    void aplicarEfeito(Caravana& caravana, Simulador& simulador) override;
};

class Mina : public Item {
public:
    Mina();
    void aplicarEfeito(Caravana& caravana, Simulador& simulador) override;
};

class Surpresa : public Item {
public:
    Surpresa();
    void aplicarEfeito(Caravana& caravana, Simulador& simulador) override;
};

#endif // ITEM_H
