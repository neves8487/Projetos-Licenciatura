#include "Cidade.h"
#include <iostream>

Cidade::Cidade(char nome, int x, int y) : nome(nome), posX(x), posY(y) {}

char Cidade::getNome() const {
    return nome;
}

int Cidade::getPosX() const {
    return posX;
}

int Cidade::getPosY() const {
    return posY;
}

void Cidade::render(Buffer& buffer) const {
    buffer.setChar(posX, posY, nome); // Representação visual da cidade no mapa
}

