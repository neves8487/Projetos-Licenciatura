#include "Item.h"
#include "Simulador.h"
#include <iostream>

using namespace std;

Item::Item(const string& nome) : nome(nome) {}

string Item::getNome() const {
    return nome;
}

// Caixa de Pandora
CaixaDePandora::CaixaDePandora() : Item("Caixa de Pandora") {}
void CaixaDePandora::aplicarEfeito(Caravana& caravana, Simulador& simulador) {
    int tripulantesPerdidos = caravana.getTripulacao() * 0.2;
    caravana.reduzirTripulantes(tripulantesPerdidos);
    cout << "Caixa de Pandora: Perdeu " << tripulantesPerdidos << " tripulantes!\n";
}

// Arca do Tesouro
ArcaDoTesouro::ArcaDoTesouro() : Item("Arca do Tesouro") {}
void ArcaDoTesouro::aplicarEfeito(Caravana& caravana, Simulador& simulador) {
    int moedasGanhas = simulador.getMoedas() * 0.1;
    simulador.adicionarMoedas(moedasGanhas);
    cout << "Arca do Tesouro: Ganhou " << moedasGanhas << " moedas!\n";
}

// Jaula
Jaula::Jaula() : Item("Jaula") {}
void Jaula::aplicarEfeito(Caravana& caravana, Simulador& simulador) {
    int espacoDisponivel = 40 - caravana.getTripulacao();
    int tripulantesAdicionados = min(espacoDisponivel, 5);
    caravana.adicionarTripulantes(tripulantesAdicionados);
    cout << "Jaula: Adicionou " << tripulantesAdicionados << " tripulantes!\n";
}

// Mina
Mina::Mina() : Item("Mina") {}
void Mina::aplicarEfeito(Caravana& caravana, Simulador& simulador) {
    simulador.removerCaravana(caravana); // remove a caravana
    cout << "Mina: A caravana foi destruída!\n";
}


// Surpresa
Surpresa::Surpresa() : Item("Surpresa") {}
void Surpresa::aplicarEfeito(Caravana& caravana, Simulador& simulador) {
    int escolha = rand() % 3;
    if (escolha == 0) {
        simulador.adicionarMoedas(50);
        cout << "Surpresa: Ganhou 50 moedas!\n";
    } else if (escolha == 1) {
        caravana.adicionarTripulantes(3);
        cout << "Surpresa: Adicionou 3 tripulantes!\n";
    } else {
        caravana.reduzirTripulantes(3);
        cout << "Surpresa: Perdeu 3 tripulantes!\n";
    }
}
