#ifndef CIDADE_H
#define CIDADE_H

#include <string>
#include "Buffer.h"

class Cidade {
private:
    char nome;
    int posX, posY;

public:
    Cidade(char nome, int x, int y);
    char getNome() const;
    int getPosX() const;
    int getPosY() const;
    void render(Buffer& buffer) const; // Renderiza a cidade no buffer

};

#endif // CIDADE_H
