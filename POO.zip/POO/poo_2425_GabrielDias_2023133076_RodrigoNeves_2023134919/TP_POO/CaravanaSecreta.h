#ifndef TP_POO_CARAVANASECRETA_H
#define TP_POO_CARAVANASECRETA_H

#include "Caravana.h"

class CaravanaSecreta : public Caravana {
private:
    int id;
public:
    CaravanaSecreta(int id, int x, int y);

};

#endif //TP_POO_CARAVANASECRETA_H
