#include "CaravanaSecreta.h"

CaravanaSecreta::CaravanaSecreta(int id, int x, int y)
        : Caravana(id, 10,50, 100,0, 1000, x, y) {}

