#include "Buffer.h"
using namespace std;

Buffer::Buffer(int r, int c) : rows(r), cols(c), buffer(r * c, '.') {}

void Buffer::clear() {
    fill(buffer.begin(), buffer.end(), '.');
}

void Buffer::setChar(int x, int y, char c) {
    if (x >= 0 && x < rows && y >= 0 && y < cols)
        buffer[x * cols + y] = c;
}

void Buffer::display() const {
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j)
            cout << buffer[i * cols + j];
        cout << endl;
    }
}