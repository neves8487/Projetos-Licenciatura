#ifndef BUFFER_H
#define BUFFER_H

#include <vector>
#include <string>
#include <iostream>
using namespace std;

class Buffer {
private:
    int rows, cols;
    vector<char> buffer;

public:
    Buffer(int r, int c);
    void clear();
    int getRows() const { return rows; }
    int getCols() const { return cols; }
    char getChar(int x, int y) const { return buffer[x * cols + y]; }
    void setChar(int x, int y, char c);
    void display() const;
};

#endif // BUFFER_H