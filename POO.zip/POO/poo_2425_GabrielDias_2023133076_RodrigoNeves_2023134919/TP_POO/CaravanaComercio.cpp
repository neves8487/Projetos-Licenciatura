#include "CaravanaComercio.h"
#include <iostream>

CaravanaComercio::CaravanaComercio(int id, int x, int y)
        : Caravana(id, 2, 40, 40, 0, 200, x, y), mercadoria(40) {}

void CaravanaComercio::sofrerTempestade() {
    float ocupacaoCarga = static_cast<float>(carga) / capacidadeCarga;
    int chanceDestruicao = (ocupacaoCarga > 0.5) ? 50 : 25;
    if (rand() % 100 < chanceDestruicao) {
        std::cout << "A Caravana de Comercio foi destruida!\n";
        tripulantes = 0;
    } else {
        carga -= carga * 0.25;
        std::cout << "A Caravana de Comercio perdeu 25% da sua carga.\n";
    }
    if (tripulantes > 0) --tripulantes;
    if (agua > 0) agua -= 2;
}
void CaravanaComercio::comportamentoAutonomo(const Buffer& buffer) {
    int randomDirection = std::rand() % 4;
    std::string direction;
    switch (randomDirection) {
        case 0: direction = "C"; break; // Move up
        case 1: direction = "B"; break; // Move down
        case 2: direction = "E"; break; // Move left
        case 3: direction = "D"; break; // Move right
    }
    move(direction, buffer);
}