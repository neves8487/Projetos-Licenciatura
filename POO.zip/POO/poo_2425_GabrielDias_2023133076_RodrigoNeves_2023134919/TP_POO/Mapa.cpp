#include "Mapa.h"
#include <fstream>
#include <stdexcept>

using namespace std;

Mapa::Mapa() : rows(0), cols(0) {
    // Inicializa os vetores de cidades, caravanas, etc.
    // Se necessário, inicialize outras variáveis aqui.
}

void Mapa::loadFromFile(const string& filename) {
    ifstream file(filename);
    if (!file) {
        throw runtime_error("Erro ao abrir o arquivo do mapa!");
    }
    string line;
    file >> line >> rows; // Lê "linhas <número>"
    file >> line >> cols; // Lê "colunas <número>"
    file.ignore();
    layout.resize(rows);
    for (int i = 0; i < rows; ++i) {
        getline(file, layout[i]); // Lê o layout do mapa
        // Detecta cidades e caravanas
        for (int j = 0; j < cols; ++j) {
            char c = layout[i][j];
            if (isalpha(c)) {
                cidades.emplace_back(c, i, j); // Adiciona cidade
            } else if (isdigit(c)) {
                // Adiciona caravana (número representa o ID da caravana)
                caravanas.emplace_back(c - '0', 0, 0, 0,
                                       0, 0, i, j);
            } else if (c == '!') {
                // Adiciona caravana bárbara
                caravanasBarbaras.emplace_back(i, j);
            }
        }
    }
    // Carrega configurações adicionais, como moedas e preços
    while (file >> line) {
        int value;
        file >> value;
        config[line] = value;
    }
}

int Mapa::getPrecoCompraMercadoria() const {
    auto it = config.find("preço_compra_mercadoria");
    if (it != config.end()) {
        return it->second;
    }
    throw runtime_error("Preco de compra de mercadoria nao encontrado no arquivo de configuracao!");
}

int Mapa::getMoedas() const {
    auto it = config.find("moedas");
    if (it != config.end()) {
        return it->second;
    }
    throw runtime_error("moedas nao encontradas no arquivo de configuracao!");
}

int Mapa::getPrecoVendaMercadoria() const {
    auto it = config.find("preço_venda_mercadoria");
    if (it != config.end()) {
        return it->second;
    }
    throw runtime_error("Preco de venda de mercadoria nao encontrado no arquivo de configuracao!");
}

int Mapa::getPrecoCaravana() const {
    auto it = config.find("preço_caravana");
    if (it != config.end()) {
        return it->second;
    }
    throw runtime_error("Preco de compra de caravana nao encontrado no arquivo de configuracao!");
}

void Mapa::render(Buffer& buffer) const {
    // Renderiza o layout do mapa
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            if (!isdigit(layout[i][j]) && layout[i][j] != '!') {
                buffer.setChar(i, j, layout[i][j]); // Renderiza cada caractere do mapa, exceto números e '!', pois ao adicionar á lista do simulador, apareciam duplicados
            }
        }
    }

    // Renderiza as cidades
    for (const auto& cidade : cidades) {
        cidade.render(buffer);
    }
}

bool Mapa::existeCidade(const string& nome) const {
    for (const auto& cidade : cidades) {
        if (cidade.getNome() == nome[0]) {
            return true;
        }
    }
    return false;
}

int Mapa::getPosXDaCidade(const string& nome) const {
    for (const auto& cidade : cidades) {
        if (cidade.getNome() == nome[0]) {
            return cidade.getPosX();
        }
    }
    throw invalid_argument("Cidade nao encontrada: " + nome);
}

int Mapa::getPosYDaCidade(const string& nome) const {
    for (const auto& cidade : cidades) {
        if (cidade.getNome() == nome[0]) {
            return cidade.getPosY();
        }
    }
    throw invalid_argument("Cidade nao encontrada: " + nome);
}

bool Mapa::isCidade(int x, int y) const {
    for (const auto& cidade : cidades) {
        if (cidade.getPosX() == x && cidade.getPosY() == y) {
            return true; // Encontra a cidade na posição x, y
        }
    }
    return false;
}