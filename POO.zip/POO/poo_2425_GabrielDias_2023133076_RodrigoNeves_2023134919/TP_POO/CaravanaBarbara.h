#ifndef CARAVANABARBARA_H
#define CARAVANABARBARA_H

#include "Caravana.h"

class CaravanaBarbara : public Caravana {
public:
    CaravanaBarbara(int x, int y);

    void comportamentoAutonomo(const Buffer& buffer) override;
    void render(Buffer& buffer) const override;
    void sofrerTempestade() override; // Adiciona a implementação do método
};

#endif // CARAVANABARBARA_H