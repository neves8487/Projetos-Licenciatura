#include "Simulador.h"
#include "CaravanaBarbara.h"
#include <sstream>
#include <iostream>
#include <fstream>
#include <stdexcept>
#include <algorithm>
using namespace std;

Simulador::Simulador(int rows, int cols)
        : buffer(rows, cols), idCounter(1){}

Simulador::~Simulador() {
}

// Inicializa o simulador lendo o arquivo de configuração
void Simulador::iniciar(const string& configFile) {
    mapa.loadFromFile(configFile);  // Carrega o mapa
    cout << "Mapa carregado com sucesso!" << endl;
    rows = mapa.getRows();
    cols = mapa.getCols();
    precoMercadoria = mapa.getPrecoCompraMercadoria();
    precoVendaMercadoria = mapa.getPrecoVendaMercadoria();
    moedas = mapa.getMoedas();
    precoCaravana = mapa.getPrecoCaravana();
    buffer = Buffer(rows, cols); // Atualiza o buffer com as novas dimensões

    // Adiciona caravanas do mapa ao simulador
    for (const auto& caravana : mapa.getCaravanas()) {
        adicionarCaravana(caravana);
    }
    for (const auto& caravanaBarbara : mapa.getCaravanasBarbaras()) {
        adicionarCaravanaBarbara(caravanaBarbara);
    }

}

// Renderiza o estado atual do jogo (mapa, caravanas, cidades)
void Simulador::renderizar() {
    buffer.clear();
    mapa.render(buffer);

    // Renderiza as caravanas
    for (auto caravana : caravanas) {
        caravana.render(buffer);
    }
    for (auto caravanaBarbara : caravanabarbara) {
        caravanaBarbara.render(buffer);
    }
    buffer.display();
    cout<<endl;
    cout << "Moedas: " << moedas << endl;
    cout << "Preco de Compra de Mercadoria: " << precoMercadoria << endl;
    cout << "Preco de Venda de Mercadoria: " << precoVendaMercadoria << endl;
    cout << "Preco de Caravana: " << precoCaravana << endl;


}

void Simulador::adicionarCaravana(Caravana caravana) {
    caravana.setId(idCounter++);
    caravanas.push_back(caravana);
}

void Simulador::adicionarCaravanaBarbara(CaravanaBarbara caravana) {
    caravana.setId(-1);
    caravanabarbara.push_back(caravana);
}

void Simulador::gastarMoedas(int quantidade) {
    if (quantidade > moedas) {
        throw runtime_error("Moedas insuficientes!");
    }
    moedas -= quantidade;
}
void Simulador::listarCaravanasNaCidade(const string& nomeCidade) {
    // Verifica a posição da cidade no mapa
    int posX = mapa.getPosXDaCidade(nomeCidade);
    int posY = mapa.getPosYDaCidade(nomeCidade);

    // Itera pelas caravanas e lista as que estão na mesma posição (x, y)
    bool encontrouCaravana = false;
    for (const auto& caravana : caravanas) {
        if (caravana.getPosX() == posX && caravana.getPosY() == posY) {
            cout << "Caravana " << caravana.getId() << " esta na cidade " << nomeCidade << "." << endl;
            encontrouCaravana = true;
        }
    }

    if (!encontrouCaravana) {
        cout << "Nenhuma caravana encontrada na cidade " << nomeCidade << "." << endl;
    }
}
void Simulador::listarPrecos() {
    cout << "Preco por mercadoria: " << precoMercadoria << " moedas" << endl;
    cout << "Preco por tripulante: " << precoTripulante << " moedas" << endl;
}

// Processa os comandos inseridos pelo jogador
void Simulador::processarComando(const string& comando) {
    istringstream iss(comando);
    string cmd;
    iss >> cmd;

    try {
        if (cmd == "prox") { // Avança turnos
            int n = 1;
            if (iss >> n) {
                for (int i = 0; i < n; ++i)
                    executarTurno();
            } else {
                executarTurno();
            }
        }else if (cmd == "exec") { // Configura o simulador com um arquivo de configuração
            string nomeFicheiro;
            if (iss >> nomeFicheiro) {

                renderizar(); // Atualiza a renderização do estado do jogo

                // Abre o arquivo de comandos e executa cada comando
                ifstream comandosFile(nomeFicheiro);
                if (!comandosFile) {
                    throw runtime_error("Erro ao abrir o arquivo de comandos!");
                }

                string comando;
                while (getline(comandosFile, comando)) {
                    processarComando(comando);
                }
            } else {
                throw invalid_argument("Uso: exec <nomeFicheiro>");
            }
        }else if (cmd == "barbaro") { // Adiciona caravana bárbara
            int x, y;
            if (iss >> x >> y) {
                adicionarBarbaro(x, y);
            } else {
                throw invalid_argument("Uso: barbaro <x> <y>");
            }
        } else if (cmd == "comprac") { // Compra uma caravana
            string cidade;
            char tipo;
            if (iss >> cidade >> tipo) {
                comprarCaravana(cidade, tipo);
            } else {
                throw invalid_argument("Uso: comprac <C> <T>");
            }
        } else if (cmd == "move") { // Move uma caravana
            int id;
            string direcao;
            if (iss >> id >> direcao) {
                moverCaravana(id, direcao);
            } else {
                throw invalid_argument("Uso: move <ID> <DIRECAO>");
            }
        } else if (cmd == "areia") { // Cria tempestade de areia
            int x, y, raio;
            if (iss >> x >> y >> raio) {
                criarTempestadeDeAreia(x, y, raio);
            } else {
                throw invalid_argument("Uso: areia <x> <y> <r>");
            }
        } else if (cmd == "cidade") { // Lista uma cidade
            string nome;
            if (iss >> nome) {
                // Listar as caravanas na cidade
                listarCaravanasNaCidade(nome);
            } else {
                throw invalid_argument("Uso: cidade <NOME>");
            }
        }else if (cmd == "precos") {  // Lista os preços das mercadorias e da tripulação
            listarPrecos();
        }
        else if (cmd == "caravana") {
            int id;
            if (iss >> id) {
                auto it = find_if(caravanas.begin(), caravanas.end(), [id](const Caravana& caravana) {
                    return caravana.getId() == id;
                });

                if (it != caravanas.end()) {
                    cout << it->getDescricao() << endl;
                } else {
                    cerr << "Caravana com ID " << id << " nao encontrada." << endl;
                }
            } else {
                throw invalid_argument("Uso: caravana <ID>");
            }
        } else if (cmd == "vende") { // Vende mercadorias de uma caravana
            int id;
            if (iss >> id) {
                venderMercadoria(id);
            } else {
                throw invalid_argument("Uso: vende <ID>");
            }

        }
        else if (cmd == "compra") { // Compra mercadorias para a caravana
            int idCaravana, quantidade;
            if (iss >> idCaravana >> quantidade) {
                comprarMercadoria(idCaravana, quantidade);
            } else {
                throw invalid_argument("Uso: compra <N> <M>");
            }
        }
        else if (cmd == "tripul") {  // Compra tripulantes para a caravana
            string idCaravanaStr;
            int quantidade;
            if (iss >> idCaravanaStr >> quantidade) {
                int idCaravana = stoi(idCaravanaStr);  // Converte o ID da caravana para inteiro
                comprarTripulantes(idCaravana, quantidade);  // Chama a função de compra de tripulantes
            } else {
                throw invalid_argument("Uso: tripul <ID_CARAVANA> <QUANTIDADE>");
            }
        }
        else if (cmd == "moedas") {  // Adiciona ou subtrai moedas para o jogador
            int quantidade;
            if (iss >> quantidade) {
                adicionarMoedas(quantidade);  // Chama a função de adicionar moedas (positivas ou negativas)
                cout << "Quantidade de moedas atualizada: " << moedas << endl;
            } else {
                throw invalid_argument("Uso: moedas <N>");
            }
        }
        else if (cmd == "auto") { // Coloca a caravana em auto-gestão
            int id;
            if (iss >> id) {
                auto it = find_if(caravanas.begin(), caravanas.end(), [id](const Caravana& caravana) {
                    return caravana.getId() == id;
                });

                if (it != caravanas.end()) {
                    it->comportamentoAutonomo(buffer);
                    cout << "Caravana " << id << " está agora em auto-gestão." << endl;
                } else {
                    cerr << "Caravana com ID " << id << " não encontrada." << endl;
                }
            }

        }
        else if (comando == "terminar") {
            exit(0);
        }

        else {
            throw invalid_argument("Comando desconhecido: " + cmd);
        }
    } catch (const exception& e) {
        cerr << "Erro ao processar comando: " << e.what() << endl;
    }
}

// Executa as ações de um turno
void Simulador::executarTurno() {
    for (auto it = caravanas.begin(); it != caravanas.end(); ) {
        it->comportamentoAutonomo(buffer); // Cada caravana realiza sua ação
        if (it->getTripulacao() == 0) {
            it = caravanas.erase(it); // Remove a caravana se não tiver tripulantes
        } else {
            ++it;
        }
    }
    for (auto it = caravanabarbara.begin(); it != caravanabarbara.end(); ) {
        it->comportamentoAutonomo(buffer); // Cada caravana realiza sua ação
        if (it->getTripulacao() == 0) {
            it = caravanabarbara.erase(it); // Remove a caravana bárbara se não tiver tripulantes
        } else {
            ++it;
        }
    }
    renderizar();
    cout << "Turno executado com sucesso." << endl;
}

// Adiciona uma caravana bárbara no mapa
void Simulador::adicionarBarbaro(int x, int y) {
    adicionarCaravanaBarbara(*new CaravanaBarbara(x, y));
    cout << "Caravana barbara adicionada em (" << x << ", " << y << ")." << endl;
}

void Simulador::comprarCaravana(const string& cidade, char tipo) {
    if (!mapa.existeCidade(cidade)) {
        throw invalid_argument("Cidade nao encontrada: " + cidade);
    }

    int x = mapa.getPosXDaCidade(cidade);
    int y = mapa.getPosYDaCidade(cidade);
    int id = idCounter;

    if (moedas < precoCaravana) {
        throw runtime_error("Moedas insuficientes para comprar uma caravana.");
    }

    if (tipo == 'C') {
        adicionarCaravana(*new CaravanaComercio(id, x, y));
    } else if (tipo == 'M') {
        adicionarCaravana(*new CaravanaMilitar(id, x, y));
    } else if (tipo == 'S') {
        adicionarCaravana(*new CaravanaSecreta(id, x, y));
    } else {
        throw invalid_argument("Tipo de caravana invalido: use 'C' ou 'M' ou 'S'.");
    }

    gastarMoedas(precoCaravana);
    cout << "Caravana comprada com sucesso na cidade " << cidade << "!" << endl;
}

// Move uma caravana na direção especificada
void Simulador::moverCaravana(int id, const std::string& direcao) {
    auto it = find_if(caravanas.begin(), caravanas.end(), [id](const Caravana& caravana) {
        return caravana.getId() == id;
    });

    if (it == caravanas.end()) {
        throw invalid_argument("ID da caravana invalido.");
    }

    buffer.setChar(it->getPosX(), it->getPosY(), ' ');

    // Verificação de direções válidas
    if (direcao != "C" && direcao != "B" && direcao != "E" && direcao != "D"
        && direcao != "CE" && direcao != "CD" && direcao != "BE" && direcao != "BD") {
        throw invalid_argument("Direcao invalida. Use 'C' para Cima, 'B' para Baixo, 'E' para Esquerda, 'D' para Direita"
                               ", 'CE' para Cima-Esquerda, 'CD' para Cima-Direita, 'BE' para Baixo-Esquerda ou 'BD' para Baixo-Direita.");
    }

    it->move(direcao, buffer); // Move de acordo com a direção fornecida
}

const vector<Caravana>& Simulador::getCaravanas() const {
    return caravanas;
}


void Simulador::comprarTripulantes(int idCaravana, int quantidade) {
    auto it = find_if(caravanas.begin(), caravanas.end(), [idCaravana](const Caravana& caravana) {
        return caravana.getId() == idCaravana;
    });

    if (it != caravanas.end()) {
        // Verifique se a caravana está em uma cidade
        int x = it->getPosX();
        int y = it->getPosY();

        // Supondo que mapa.isCidade(x, y) verifica se a posição é uma cidade
        if (!mapa.isCidade(x, y)) {
            cerr << "A caravana não está em uma cidade para comprar tripulantes." << endl;
            return;
        }

        // Verifique se o jogador tem moedas suficientes
        int custo = quantidade * precoTripulante;  // Cálculo do custo para os tripulantes

        if (moedas >= custo ) {
            // Verifique se há espaço suficiente na caravana para os tripulantes
            int capacidadeMaxima = it->getCapacidadeTripulantes(); // Assume que a caravana tem um método para retornar a capacidade máxima
            int tripulantesAtuais = it->getTripulacao();  // Assume que a caravana tem um método para retornar o número atual de tripulantes

            if (tripulantesAtuais + quantidade > capacidadeMaxima) {
                cerr << "Não há espaço suficiente para comprar " << quantidade << " tripulantes." << endl;
                return;
            }

            it->adicionarTripulantes(quantidade);  // Adiciona os tripulantes à caravana
            moedas -= custo;  // Deduz o custo das moedas do jogador
            cout << "Comprados " << quantidade << " tripulantes para a caravana " << idCaravana << "." << endl;
        } else {
            cerr << "Moedas insuficientes para comprar tripulantes." << endl;
        }
    } else {
        cerr << "Caravana com ID " << idCaravana << " não encontrada." << endl;
    }
}

int Simulador::getMoedas() const {
    return moedas;
}

void Simulador::adicionarMoedas(int quantidade) {
    if (moedas + quantidade < 0) {
        throw std::runtime_error("Não é possível ter moedas negativas.");
    }
    moedas += quantidade;  // Adiciona ou subtrai as moedas conforme o valor de "quantidade"
}


void Simulador::venderMercadoria(int idCaravana) {
    auto it = find_if(caravanas.begin(), caravanas.end(), [idCaravana](const Caravana& caravana) {
        return caravana.getId() == idCaravana;
    });

    if (it != caravanas.end()) {
        int lucro =it->venderMercadoria(precoVendaMercadoria);
        moedas += lucro;

        cout << "Mercadoria vendida pela caravana " << idCaravana << " por " << lucro << " moedas." << endl;
    } else {
        cerr << "Caravana com ID " << idCaravana << " não encontrada." << endl;
    }
}

void Simulador::comprarMercadoria(int idCaravana, int quantidade) {
    auto it = find_if(caravanas.begin(), caravanas.end(), [idCaravana](const Caravana& caravana) {
        return caravana.getId() == idCaravana;
    });

    if (it != caravanas.end()) {
        // verifica se a caravana esta numa cidade
        int x = it->getPosX();
        int y = it->getPosY();

        if (!mapa.isCidade(x, y)) {
            cerr << "A caravana não está em uma cidade para comprar mercadorias." << endl;
            return;
        }

        // Verifica se a quantidade é válida
        if (quantidade <= 0) {
            cerr << "Quantidade inválida para compra." << endl;
            return;
        }

       //verifica se o jogador tem moedas suficientes
        int custo = precoMercadoria;
        if (moedas >= custo) {
            if (it->adicionarMercadoria(quantidade)) {
                moedas -= custo;
                cout << "Compradas " << quantidade << " toneladas de mercadoria para a caravana " << idCaravana << "." << endl;
            } else {
                cerr << "Capacidade de carga excedida para a caravana " << idCaravana
                     << ". Carga atual: " << it->getCarga()
                     << ", Capacidade máxima: " << it->getCapacidadeCarga() << "." << endl;
            }
        } else {
            cerr << "Moedas insuficientes para comprar mercadorias." << endl;
        }
    } else {
        cerr << "Caravana com ID " << idCaravana << " não encontrada." << endl;
    }
}



void Simulador::removerCaravanaBarbara(const CaravanaBarbara& caravanaBarbara) {
    // Encontrar e remover a caravana bárbara do vetor (por ID ou referência)
    auto it = std::find_if(caravanabarbara.begin(), caravanabarbara.end(),
                           [&caravanaBarbara](const CaravanaBarbara& c) { return c.getId() == caravanaBarbara.getId(); });

    if (it != caravanabarbara.end()) {
        caravanabarbara.erase(it);  // Remove a caravana bárbara encontrada
        std::cout << "Caravana Bárbara " << caravanaBarbara.getId() << " removida com sucesso.\n";
    } else {
        std::cout << "Caravana Bárbara com ID " << caravanaBarbara.getId() << " não encontrada.\n";
    }
}

void Simulador::removerCaravana(const Caravana& caravana) {
    // Encontrar e remover a caravana do vetor (por ID ou referência)
    auto it = std::find_if(caravanas.begin(), caravanas.end(),
                           [&caravana](const Caravana& c) { return c.getId() == caravana.getId(); });

    if (it != caravanas.end()) {
        caravanas.erase(it);  // Remove a caravana encontrada
        std::cout << "Caravana " << caravana.getId() << " removida com sucesso.\n";
    } else {
        std::cout << "Caravana com ID " << caravana.getId() << " não encontrada.\n";
    }
}
void Simulador::criarTempestadeDeAreia(int x, int y, int raio) {
    for (auto it = caravanas.begin(); it != caravanas.end(); ) {
        int dx = it->getPosX() - x;
        int dy = it->getPosY() - y;
        if (dx * dx + dy * dy <= raio * raio) {
            it->sofrerTempestade();
            std::cout << "Caravana afetada pela tempestade em (" << it->getPosX() << ", " << it->getPosY() << ").\n";
        }
        if (it->getTripulacao() == 0) {
            it = caravanas.erase(it); // Remove a caravana se não tiver tripulantes
        } else {
            ++it;
        }
    }
    for (auto it = caravanabarbara.begin(); it != caravanabarbara.end(); ) {
        int dx = it->getPosX() - x;
        int dy = it->getPosY() - y;
        if (dx * dx + dy * dy <= raio * raio) {
            it->sofrerTempestade();
            std::cout << "Caravana Bárbara afetada pela tempestade em (" << it->getPosX() << ", " << it->getPosY() << ").\n";
        }
        if (it->getTripulacao() == 0) {
            it = caravanabarbara.erase(it); // Remove a caravana bárbara se não tiver tripulantes
        } else {
            ++it;
        }
    }
}