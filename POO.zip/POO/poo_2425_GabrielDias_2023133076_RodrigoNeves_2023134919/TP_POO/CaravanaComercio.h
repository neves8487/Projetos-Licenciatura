#ifndef CARAVANACOMERCIO_H
#define CARAVANACOMERCIO_H

#include "Caravana.h"

class CaravanaComercio : public Caravana {
private:
    int mercadoria;
    int id;
public:
    CaravanaComercio(int id, int x, int y);
    void comportamentoAutonomo(const Buffer& buffer);
    void sofrerTempestade() override;
};

#endif // CARAVANACOMERCIO_H