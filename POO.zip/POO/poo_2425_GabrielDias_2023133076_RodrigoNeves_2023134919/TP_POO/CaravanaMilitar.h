#ifndef CARAVANA_MILITAR_H
#define CARAVANA_MILITAR_H

#include "Caravana.h"

class CaravanaMilitar : public Caravana {
public:
    CaravanaMilitar(int id, int x, int y);
    void sofrerTempestade() override;
    void comportamentoAutonomo(const Buffer& buffer) override;
};

#endif // CARAVANA_MILITAR_H